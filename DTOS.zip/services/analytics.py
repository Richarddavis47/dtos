"""DTOS analytics service module."""
