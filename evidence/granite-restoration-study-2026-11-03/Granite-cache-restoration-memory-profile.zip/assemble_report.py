from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
from datetime import datetime,timezone
root=Path('/workspace/2226-efficiency');scale=root/'granite-scale';m=1024**2
baseline='150339f3d02e40ef161a8eb5d870e9b7c38f5874';tree='e4669e8a4517e29f1d45a332580a52af439adab1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/dtos',text=True).strip()==baseline
assert not subprocess.check_output(['git','status','--porcelain'],cwd='/workspace/dtos',text=True).strip()
fixture=json.loads((scale/'profile.json').read_text());variants={r['league_id']:r for r in fixture['variants']}
for r in variants.values():assert hashlib.file_digest((scale/r['filename']).open('rb'),'sha256').hexdigest()==r['sha256']
profiles=[]
for p in sorted(scale.glob('profile-*.json')):
 d=json.loads(p.read_text());assert d['head']==baseline and d['tree']==tree and d['passed'] and d['complete']
 assert d['enforced_limit']==2*1024**3 and d['swap_limit']==0 and not d['scratch_exists_after'] and d['monitor_exited']
 assert not d['final']['cgroup_memory_events']['oom_kill']
 for r in d['restores']:
  if r['outcome']=='restored':
   assert r['projection_attached']
   assert r['projection_snapshot_id'] in {x['projection_generation'] for x in variants.values()}
   assert r['source_generations']['projections']==r['projection_snapshot_id']
 profiles.append(d)
healthy=json.loads((scale/'profile-oneqb.json-healthy.json').read_text());prototype=json.loads((scale/'profile-oneqb.json-healthy-prototype.json').read_text())
assert healthy['restores'][0]['source_generations']==prototype['restores'][0]['source_generations']
assert healthy['restores'][0]['observed_increment']==healthy['final']['kernel_lifetime_peak_bytes']-healthy['restores'][0]['before']['cgroup_current_bytes']
repeat=json.loads((scale/'minimal-repeat-result.json').read_text());assert repeat['passed'] and repeat['complete'] and repeat['scratch_removed']
cleanup=json.loads((scale/'cleanup-stages-result.json').read_text());assert cleanup['passed'] and cleanup['complete']
log=(root/'focused-controls.log').read_text();assert re.search(r'Ran 36 tests in 19\.120s\s+OK',log)
provided={'source':'Operator measurements supplied by product owner; not freshly collected by this Codex run.','observed_at':'2026-11-03T13:55:00-05:00','cache_bytes':23048708,'container_usage_mib_approximately':1687,'container_limit_mib':2048,'raw_headroom_mib_approximately':361,'cache_age_approximately':'9h51m','recorded_oom_events':0,'earlier_1701_rejection_reason':'Not retrospectively established by this later measurement.'}
(root/'operator-supplied-input.json').write_text(json.dumps(provided,indent=2)+'\n')
rows=[]
for d in profiles:
 for r in d['restores']:
  rows.append({k:r.get(k) for k in ('label','outcome','seconds','raw_headroom','required','observed_increment','observed_peak','fois_reserved')}|{'scenario':d['scenario'],'cache':d['cache'],'prototype_only':d.get('prototype_only_skip_discarded_hash',False)})
close=cleanup['samples'][1]
report={'generated_at':datetime.now(timezone.utc).isoformat(),'application_commit':baseline,'application_tree':tree,'application_changed':False,'release_created':False,'deployed':False,'scope':'New enforced-container fixture measurements, not private Granite cache contents or live Granite recovery.','reported_production':provided,
'unchanged_admission':{'factor':16,'minimum_working_bytes':128*m,'safety_bytes':128*m,'fois_additional_working_bytes':640*m,'trade_working_bytes':256*m,'trade_safety_bytes':128*m,'granite_working_bytes':23048708*16,'granite_required_without_fois_bytes':23048708*16+128*m,'granite_required_with_fois_bytes':23048708*16+768*m,'additional_free_capacity_without_fois_mib':(23048708*16+128*m)/m-361},
'fixture':{'cache_bytes':healthy['cache_bytes'],'actual_granite_bytes':23048708,'size_ratio':healthy['cache_bytes']/23048708,'teams':12,'rostered_players':288,'catalog_identities':10500,'canonical_projection_rows':1288,'compatible_durable_projection_restored':True,'weeks':[8,9],'publication_shape_limitations':fixture['catalog_shape_limitations']},
'healthy':{'seconds':healthy['restores'][0]['seconds'],'kernel_confirmed_peak_increment_bytes':healthy['restores'][0]['observed_increment'],'kernel_peak_bytes':healthy['final']['kernel_lifetime_peak_bytes'],'retained_before_close_increment_bytes':healthy['restores'][0]['after']['cgroup_current_bytes']-healthy['restores'][0]['before']['cgroup_current_bytes'],'stages':[{'name':e['stage'],'seconds':e['ended']-e['started'],'increment_bytes':e['observed_increment']} for e in healthy['events']]},
'scenario_outcomes':rows,
'cleanup':{'runtime_projection_brain_market_weakrefs_collected':True,'runtime_close_bytes':close['after_runtime_close']['cgroup_current_bytes'],'after_gc_bytes':close['after_gc']['cgroup_current_bytes'],'after_native_trim_bytes':close['memory']['cgroup_current_bytes'],'gc_collected_objects':close['gc_collected'],'minimal_repeat_cycles':12,'minimal_repeat_post_cleanup_bytes':[r['memory']['cgroup_current_bytes'] for r in repeat['samples'][1:]],'retention_qualification':'Post-cleanup usage warmed to about109MiB and plateaued in final4cycles; not all memory returns to initial baseline. Root of bounded retention is not attributed. No unbounded runtime-graph leak demonstrated in this bounded experiment.'},
'prototype':{'scope':'External fixture-only experiment; no application file changed.','change':'Avoid the full projection fallback fingerprint only when its result is immediately replaced by the existing durable projection ID.','generation_identity_preserved':True,'baseline_peak_bytes':healthy['restores'][0]['observed_increment'],'prototype_peak_bytes':prototype['restores'][0]['observed_increment'],'baseline_seconds':healthy['restores'][0]['seconds'],'prototype_seconds':prototype['restores'][0]['seconds'],'conclusion':'No overall peak reduction; no admission improvement; do not deploy as Granite availability fix.'},
'validation':{'focused_tests':36,'focused_seconds':19.120,'browser_cases':12,'browser_viewports':[[320,432],[375,667],[390,844],[1280,900]],'browser_scope':'Chromium emulation with keyboard/touch and no overflow; not physical iPhone/Safari.','profile_reports_verified':len(profiles),'full_canonical':'Not rerun: no application source change or release proposed.','hosted':'Not rerun: no application source change or release proposed.','failures_preserved':'Initial profiler asserted null instead of the documented idle lifecycle state; retained in attempt-1. A redirected log in a container-owned directory failed before application execution; rerun wrote logs in the task-owned parent.'},
'conclusion':{'sixteen_x':'Conservative compared with these fixtures, but not established as an optimal or universal bound. File size alone does not determine JSON/durable-publication allocation. No lower universal reserve proven safe.','confirmed_waste':'A discarded projection fingerprint and duplicate durable reference-envelope decoding are identifiable. The measured complete projection constructor and canonical-publication costs do not justify a119MiB admission reduction; the tested fingerprint optimization left peak unchanged.','source_correction':'None implemented or released. No reserve reduced; no code or data mutation.','ram_plan':'Not demonstrated technically necessary: compatible fixtures and warm runtimes complete within2GiB. A larger plan alone does not relax this gate because it uses min(actual_limit,2GiB). More RAM would require a separately authorized policy review to benefit this admission path; no plan/policy change is proposed. These measurements do not establish reliable production capacity under every overlapping workload.','remaining_capacity':'At the operator-reported361MiB, current policy still defers Granite even without FOIS. About118.7MiB additional genuinely free capacity is needed without FOIS. No live search was run.'},'production_readiness':json.loads((root/'production-readiness.json').read_text())}
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'README.txt').write_text('Granite-sized cache restoration memory profile\n\nApplication source remains production150339f/treee466; no implementation or release.\nRead report.json first. All cached roster/player records here are synthetic disposable fixtures; no private Granite cache was obtained. User-supplied production measurements are separately attributed.\n\nReproduce using Python3.14.3 and existing requirements on the pinned source. Run prepare_fixtures.py --output /evidence/granite-scale --catalog-players10500 --projection-extra1000 in a fresh disposable directory. Use a genuinely enforced --memory=2g --memory-swap=2g --cpus=2 --network=none container. The runtime-mount helper is environment-specific; a new environment can use the canonical validation image instead. Do not pass production credentials or stores into the container.\n\nThen profile_restore.py --root /evidence/granite-scale --scenario healthy|warm|pressure|supported_pressure|fois|fois_healthy|fois_same_pressure|incompatible|repeat. The prototype flag is external measurement code, not a production patch. It must not be described as released. Minimal_repeat.py avoids retaining mid-operation measurement dictionaries and verifies weak references disappear over12cycles. Cleanup_stages.py separately records close, fullGC and native trim. Stage increments overlap and must not be added together.\n\nThe fixture projection database must be populated before observation. Compatible durable projection restore is asserted, including current oneQB K/DEF/FLEX and separate Superflex scoring. Future first-franchise DEF is intentionally missing and remains unknown. Catalog/row densities do not reconstruct actualGranite contents; matching byte scale is not evidence of identical real demand.\n\nFailures and first-pass measurements are preserved separately. The original build2225corrigendum and immutable release assets were not edited. No live provider requests, production hydration, production Trade search, production FOIS generation or production user-data changes occurred. Production health/ready was read once; its533ms external elapsed is network+delivery, not measured liveness-handler duration.\n')
(root/'attempts.json').write_text(json.dumps({'application_test_failures':0,'attempts':[{'scope':'initial profiling harness','outcome':'failed assertion','reason':'Harness expected phase null; deployed API returns idle. Corrected harness asserts idle and no heavy owners; no application guard change.','preserved':'attempt-1/'},{'scope':'log redirection','outcome':'shell permission error before application execution','reason':'Container-created fixture directory not writable by host task user. Subsequent logs written to task-owned parent.'},{'scope':'focused regression','outcome':'passed','tests':36}]},indent=2)+'\n')
# Preserve whole raw observation files and deterministic reproduction inputs.
files=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc' or p.name in ('MANIFEST.json','SHA256SUMS') or p.suffix in ('.zip','.sha256'):continue
 rel=p.relative_to(root)
 if any(part in ('preparation-scratch','preparation-scratch.storage-lock') for part in rel.parts):continue
 if rel.parts[0]=='granite-scale' or rel.parts[0] in ('attempt-1','first-pass') or len(rel.parts)==1:files.append(p)
# Exclude the redundant first-scale source caches/store while preserving its reports/logs.
files=[p for p in files if p.name not in ('oneqb.json','oneqb-rostered.json','superflex.json','superflex-rostered.json','projections.sqlite3') or p.parent==scale]
rows=[{'name':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()} for p in files]
(root/'MANIFEST.json').write_text(json.dumps(rows,indent=2)+'\n');files.append(root/'MANIFEST.json')
(root/'SHA256SUMS').write_text(''.join(hashlib.file_digest(p.open('rb'),'sha256').hexdigest()+'  '+p.relative_to(root).as_posix()+'\n' for p in files));files.append(root/'SHA256SUMS')
out=root
zpath=out/'Granite-cache-restoration-memory-profile.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,p.relative_to(root).as_posix())
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for row in rows:
  b=z.read(row['name']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.file_digest(zpath.open('rb'),'sha256').hexdigest();(out/(zpath.name+'.sha256')).write_text(sha+'  '+zpath.name+'\n')
print(json.dumps({'report':str(root/'report.json'),'archive':str(zpath),'sha256':sha,'bytes':zpath.stat().st_size,'verified_payloads':len(rows),'profiles':len(profiles)},indent=2))
