Granite-sized cache restoration memory profile

Application source remains production150339f/treee466; no implementation or release.
Read report.json first. All cached roster/player records here are synthetic disposable fixtures; no private Granite cache was obtained. User-supplied production measurements are separately attributed.

Reproduce using Python3.14.3 and existing requirements on the pinned source. Run prepare_fixtures.py --output /evidence/granite-scale --catalog-players10500 --projection-extra1000 in a fresh disposable directory. Use a genuinely enforced --memory=2g --memory-swap=2g --cpus=2 --network=none container. The runtime-mount helper is environment-specific; a new environment can use the canonical validation image instead. Do not pass production credentials or stores into the container.

Then profile_restore.py --root /evidence/granite-scale --scenario healthy|warm|pressure|supported_pressure|fois|fois_healthy|fois_same_pressure|incompatible|repeat. The prototype flag is external measurement code, not a production patch. It must not be described as released. Minimal_repeat.py avoids retaining mid-operation measurement dictionaries and verifies weak references disappear over12cycles. Cleanup_stages.py separately records close, fullGC and native trim. Stage increments overlap and must not be added together.

The fixture projection database must be populated before observation. Compatible durable projection restore is asserted, including current oneQB K/DEF/FLEX and separate Superflex scoring. Future first-franchise DEF is intentionally missing and remains unknown. Catalog/row densities do not reconstruct actualGranite contents; matching byte scale is not evidence of identical real demand.

Failures and first-pass measurements are preserved separately. The original build2225corrigendum and immutable release assets were not edited. No live provider requests, production hydration, production Trade search, production FOIS generation or production user-data changes occurred. Production health/ready was read once; its533ms external elapsed is network+delivery, not measured liveness-handler duration.
