"""Disposable instrumentation of the unchanged production restoration path."""
import argparse,asyncio,gc,hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
from unittest.mock import patch

args=argparse.ArgumentParser();args.add_argument('--scenario',default='healthy');args.add_argument('--cache',default='oneqb.json');args.add_argument('--root',default='/evidence');args.add_argument('--prototype-skip-discarded-hash',action='store_true');a=args.parse_args()
root=Path(a.root);scratch=tempfile.TemporaryDirectory(prefix='restore-profile-');sp=Path(scratch.name)
for key,name in {'CACHE':'cache.json','METADATA_DB':'metadata.sqlite3','INTELLIGENCE_CHECKPOINT':'intelligence.sqlite3','FOIS_DB':'fois.sqlite3','HISTORY_DB':'history.sqlite3','ACCOUNT_DB':'accounts.sqlite3'}.items():os.environ['DTOS_'+key+'_FILE']=str(sp/name)
os.environ.update(DTOS_PROJECTION_DB_FILE=str(root/'projections.sqlite3'),DTOS_DURABLE_HISTORY_REQUIRED='0',SLEEPER_BASE_URL='http://127.0.0.1:9/v1',DTOS_SLEEPER_SEASON_CACHE_ROOT=str(sp/'seasons'),DTOS_HISTORY_STORAGE_ROOT=str(sp))
sys.path.insert(0,str(Path.cwd()))
import psutil
import dtos_app
from fastapi.testclient import TestClient
from services import league_preparation as prep
from src.core.league_runtime import LeagueRuntime
from src.core.projection_intelligence import state_storage,retention
from src.core.league_runtime import context as canonical
from src.platform.lifecycle import memory_snapshot,lifecycle_coordinator,HeavyWorkDeferred
from src.platform.memory_reclamation import release_unused_allocator_pages

cache=root/a.cache
metadata=json.loads((root/'profile.json').read_text())
case=next(r for r in metadata['variants'] if r['filename']==a.cache)
if a.prototype_skip_discarded_hash:
 original_refresh=canonical.CanonicalLeagueContext.refresh_generations
 original_sources=canonical.source_generations
 def prototype_refresh(self):
  snapshot=self.projection.snapshot() or {}
  if not snapshot.get('projection_snapshot_id'):return original_refresh(self)
  def avoid_discarded(data,profile):return original_sources({**data,'projection_intelligence':{}},profile)
  with patch.object(canonical,'source_generations',side_effect=avoid_discarded):return original_refresh(self)
 prototype_patch=patch.object(canonical.CanonicalLeagueContext,'refresh_generations',prototype_refresh)
 prototype_patch.start()
assert int(Path('/sys/fs/cgroup/memory.max').read_text())==2*1024**3
assert Path('/sys/fs/cgroup/memory.swap.max').read_text().strip()=='0'
report={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'scenario':a.scenario,'prototype_only_skip_discarded_hash':a.prototype_skip_discarded_hash,'cache':a.cache,'cache_bytes':cache.stat().st_size,'cache_sha256':case.get('sha256'), 'file_cache_scope':'No premeasurement content hash/read in profiler; shared filesystem cache warmth is recorded through raw file counters.','fixture_scope':metadata['scope'],'events':[],'restores':[],'enforced_limit':2*1024**3,'swap_limit':0,'scope':'Disposable fixtures, not actual Granite cache or a production recovery claim.'}
def sample():
 s=memory_snapshot();s.update(t=time.monotonic(),rss=psutil.Process().memory_info().rss,kernel_lifetime_peak_bytes=int(Path('/sys/fs/cgroup/memory.peak').read_text()))
 for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines():
  k,v=line.split()
  if k in ('anon','file','inactive_file','kernel'):s[k]=int(v)
 return s
baseline=sample();report['initial']=baseline
samples_path=root/('samples-'+a.cache+'-'+a.scenario+'.jsonl')
monitor_code='''import json,sys,time\nfrom pathlib import Path\np=Path('/sys/fs/cgroup')\nwith open(sys.argv[1],'w',buffering=1) as out:\n while True:\n  s={'t':time.monotonic(),'current':int((p/'memory.current').read_text())}\n  out.write(json.dumps(s)+'\\n');time.sleep(.002)\n'''
monitor=subprocess.Popen([sys.executable,'-c',monitor_code,str(samples_path)])
# Allow the observer's own memory to be measured, rather than hidden.
time.sleep(.08)
def wrap(owner,name,label):
 original=getattr(owner,name)
 def measured(*xs,**kw):
  b=sample();started=time.monotonic()
  try:return original(*xs,**kw)
  finally:report['events'].append({'stage':label,'started':started,'ended':time.monotonic(),'before':b,'after':sample()})
 return patch.object(owner,name,measured)
patches=[wrap(prep.json,'load','cache_json_decode'),wrap(prep,'safe_sync_state','shallow_status_materialization'),wrap(LeagueRuntime,'apply_data','runtime_apply_reference'),wrap(dtos_app.ProjectionService,'__init__','projection_ctor_durable_decode'),wrap(dtos_app.ProjectionService,'restore_into','projection_attach_compatible'),wrap(dtos_app.BrainService,'__init__','brain_context'),wrap(dtos_app,'_publish_runtime_context','canonical_publication'),wrap(canonical,'_digest','canonical_fingerprint'),wrap(state_storage,'decode','durable_state_decode'),wrap(retention,'unpack','durable_reference_unpack')]
for p in patches:p.start()
warm=[];padding=None;fois=False
client=TestClient(dtos_app.app)
def publish(runtime):
 projection=dtos_app.ProjectionService(league_id=runtime.league_id,scoring_profile_id=runtime.scoring_profile)
 attached=projection.restore_into(runtime.state['data'])
 assert attached,projection.health()
 context=dtos_app._publish_runtime_context(runtime,projection);context.history_state='unavailable'
 report['restores'][-1]['projection_attached']=attached
 report['restores'][-1]['projection_snapshot_id']=projection.snapshot()['projection_snapshot_id']
def restore(path,league_id,label,expect='restored',expected_season=2026):
 r=LeagueRuntime(league_id);observed=[]
 def actual_sample():
  s=memory_snapshot();observed.append(dict(s));return s
 b=sample();row={'label':label,'before':b,'expected_season':expected_season};report['restores'].append(row);started=time.monotonic()
 with patch.object(prep,'league_cache_file',return_value=path),patch.object(prep,'memory_snapshot',side_effect=actual_sample):
  try:outcome='restored' if prep.restore_cached_runtime(r,publish,expected_season=expected_season) else 'incompatible'
  except HeavyWorkDeferred:outcome='deferred'
 row.update(outcome=outcome,seconds=time.monotonic()-started,after=sample(),admission_samples=observed)
 assert outcome==expect,(label,outcome,expect)
 if observed:
  used,limit=observed[0]['cgroup_current_bytes'],observed[0]['cgroup_limit_bytes'];w=max(prep.CACHE_MINIMUM_WORKING,path.stat().st_size*prep.CACHE_EXPANSION_FACTOR);required=w+prep.CACHE_SAFETY+(640*1024**2 if lifecycle_coordinator.fois_generation_active() else 0)
  row.update(working=w,required=required,raw_headroom=min(limit,2*1024**3)-used,fois_reserved=lifecycle_coordinator.fois_generation_active())
 if outcome=='restored':
  assert r.canonical_context is not None
  row['source_generations']=dict(r.source_generations)
  row['scoring_profile']=r.scoring_profile
  # Prepared lineups are reused; do not run a new provider refresh or search.
  ts=r.state['data'].get('team_strength') or {}
  row['prepared_team_count']=len(ts.get('teams') or {})
  row['slots']=r.state['data']['league']['roster_positions']
 return r

def clean(r):
 b=sample();t=time.monotonic();asyncio.run(r.close());gc.collect();release_unused_allocator_pages()
 report['events'].append({'stage':'runtime_close_gc_allocator_release','started':t,'ended':time.monotonic(),'before':b,'after':sample()})
def pressure(headroom):
 global padding
 gc.collect();release_unused_allocator_pages();used=sample()['cgroup_current_bytes'];padding=bytearray(max(0,2*1024**3-headroom-used))
 for i in range(0,len(padding),4096):padding[i]=1

def relief():
 global padding
 padding=None;gc.collect();release_unused_allocator_pages()
try:
 if a.scenario in ('warm','pressure','fois','fois_healthy','fois_same_pressure','supported_pressure'):
  other=next(r for r in metadata['variants'] if r['filename']=='superflex-rostered.json')
  warm.append(restore(root/other['filename'],other['league_id'],'warm_superflex'))
 if a.scenario=='warm':
  other=next(r for r in metadata['variants'] if r['filename'].startswith('oneqb') and r['filename']!=a.cache) if sum(r['filename'].startswith('oneqb') for r in metadata['variants'])>1 else None
  if other:warm.append(restore(root/other['filename'],other['league_id'],'warm_other_oneqb'))
 if a.scenario=='pressure':pressure(361*1024**2)
 if a.scenario=='supported_pressure':pressure(512*1024**2)
 if a.scenario in ('fois','fois_healthy','fois_same_pressure'):
  lifecycle_coordinator.reserve_fois_generation();fois=True
  if a.scenario in ('fois','fois_same_pressure'):pressure(900*1024**2)
 expected='deferred' if a.scenario in ('pressure','fois','fois_same_pressure') else 'incompatible' if a.scenario=='incompatible' else 'restored'
 target=restore(cache,case['league_id'],'target',expected,expected_season=2025 if a.scenario=='incompatible' else 2026)
 if expected=='restored':
  report['retained_after_target']=sample();clean(target);del target
 else:
  assert not target.state['data'];clean(target);del target
  if a.scenario!='fois_same_pressure':relief()
  if fois:lifecycle_coordinator.release_fois_generation();fois=False
  target=restore(cache,case['league_id'],'after_fois_release_same_pressure' if a.scenario=='fois_same_pressure' else 'explicit_recovery','restored');clean(target);del target
  relief()
 if a.scenario=='repeat':
  for i in range(5):
   target=restore(cache,case['league_id'],'repeat_'+str(i),'restored');clean(target);del target
 for r in warm:clean(r)
 warm.clear()
 try:del r
 except NameError:pass
 if fois:lifecycle_coordinator.release_fois_generation();fois=False
 report['liveness']={'status':client.get('/health/live').status_code}
 assert report['liveness']['status']==200
 report['lifecycle_after']=lifecycle_coordinator.snapshot()
 assert report['lifecycle_after']['phase']=='idle'
 assert not any(report['lifecycle_after']['heavy_work'][k] for k in ('fois_generation','historical_response','trade_search','market_critical'))
 report['passed']=True
except BaseException as exc:
 report.update(passed=False,complete=False,error_type=type(exc).__name__,error_message=str(exc))
 (root/('incomplete-'+a.cache+'-'+a.scenario+'.json')).write_text(json.dumps(report,indent=2)+'\n')
 raise
finally:
 if fois:lifecycle_coordinator.release_fois_generation()
 relief()
 for p in reversed(patches):p.stop()
 client.close();monitor.terminate();monitor.wait(timeout=5)
 scratch.cleanup();gc.collect();release_unused_allocator_pages()
report['final']=sample();report['scratch_exists_after']=sp.exists();report['monitor_exited']=monitor.poll() is not None
report['children_after_cleanup']=[p.pid for p in psutil.Process().children(recursive=True)]
assert not report['children_after_cleanup']
assert not report['scratch_exists_after'] and not report['final']['cgroup_memory_events']['oom_kill']
samples=[json.loads(s) for s in samples_path.read_text().splitlines()]
for e in report['events']:
 e['observed_peak']=max([e['before']['cgroup_current_bytes'],e['after']['cgroup_current_bytes'],*[s['current'] for s in samples if e['started']<=s['t']<=e['ended']]])
 e['observed_increment']=e['observed_peak']-e['before']['cgroup_current_bytes']
for r in report['restores']:
 t=r['before']['t'];end=r['after']['t'];r['observed_peak']=max([r['before']['cgroup_current_bytes'],r['after']['cgroup_current_bytes'],*[s['current'] for s in samples if t<=s['t']<=end]])
 r['observed_increment']=r['observed_peak']-r['before']['cgroup_current_bytes']
report['complete']=True
out=root/('profile-'+a.cache+'-'+a.scenario+('-prototype' if a.prototype_skip_discarded_hash else '')+'.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':out.name,'passed':report['passed'],'restores':[{k:r[k] for k in ('label','outcome','seconds','observed_increment','raw_headroom','required') if k in r} for r in report['restores']]},indent=2))
