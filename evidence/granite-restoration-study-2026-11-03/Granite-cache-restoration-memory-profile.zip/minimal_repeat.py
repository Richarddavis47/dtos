"""No event-retention control; same real restore/admission/publication path."""
import asyncio,gc,json,os,sys,tempfile,weakref
from pathlib import Path
from unittest.mock import patch
root=Path('/evidence/granite-scale');scratch=tempfile.TemporaryDirectory();sp=Path(scratch.name)
for k,n in {'CACHE':'cache.json','METADATA_DB':'metadata.sqlite3','INTELLIGENCE_CHECKPOINT':'intelligence.sqlite3','FOIS_DB':'fois.sqlite3','HISTORY_DB':'history.sqlite3','ACCOUNT_DB':'accounts.sqlite3'}.items():os.environ['DTOS_'+k+'_FILE']=str(sp/n)
os.environ.update(DTOS_PROJECTION_DB_FILE=str(root/'projections.sqlite3'),DTOS_DURABLE_HISTORY_REQUIRED='0',SLEEPER_BASE_URL='http://127.0.0.1:9/v1',DTOS_SLEEPER_SEASON_CACHE_ROOT=str(sp/'seasons'),DTOS_HISTORY_STORAGE_ROOT=str(sp))
sys.path.insert(0,str(Path.cwd()))
import dtos_app
from services import league_preparation as prep
from src.core.league_runtime import LeagueRuntime
from src.platform.lifecycle import memory_snapshot,lifecycle_coordinator
from src.platform.memory_reclamation import release_unused_allocator_pages
assert memory_snapshot()['cgroup_limit_bytes']==2*1024**3
assert Path('/sys/fs/cgroup/memory.swap.max').read_text().strip()=='0'
references=[]
def publish(r):
 p=dtos_app.ProjectionService(league_id=r.league_id,scoring_profile_id=r.scoring_profile)
 assert p.restore_into(r.state['data'])
 dtos_app._publish_runtime_context(r,p)
 references.extend([weakref.ref(p),weakref.ref(r.brain_context),weakref.ref(r.market_context)])
start=memory_snapshot()
output=root/'minimal-repeat.jsonl'
with output.open('w',buffering=1) as log:
 log.write(json.dumps({'stage':'initial','memory':start})+'\n')
 for i in range(12):
  r=LeagueRuntime('oneqb-rich');references=[weakref.ref(r)]
  with patch.object(prep,'league_cache_file',return_value=root/'oneqb.json'):
   assert prep.restore_cached_runtime(r,publish,expected_season=2026)
  asyncio.run(r.close());assert r.state['data']=={}
  del r;gc.collect();release_unused_allocator_pages()
  assert all(w() is None for w in references)
  log.write(json.dumps({'iteration':i,'all_runtime_projection_brain_market_refs_released':True,'memory':memory_snapshot()})+'\n')
  references.clear()
assert lifecycle_coordinator.snapshot()['phase']=='idle'
assert not lifecycle_coordinator.fois_generation_active()
scratch.cleanup();gc.collect();release_unused_allocator_pages()
rows=[json.loads(line) for line in output.read_text().splitlines()]
assert all(not r['memory']['cgroup_memory_events']['oom_kill'] for r in rows)
(root/'minimal-repeat-result.json').write_text(json.dumps({'passed':True,'complete':True,'enforced_limit':2*1024**3,'application_unchanged':True,'observer_scope':'Only post-cleanup samples serialized to disk, not retained as in-process dicts during restoration.','samples':rows,'scratch_removed':not sp.exists()},indent=2)+'\n')
print(json.dumps({'passed':True,'post_close_mib':[round(r['memory']['cgroup_current_bytes']/1024**2,3) for r in rows],'all_runtime_graph_weakrefs_collected':True}))
