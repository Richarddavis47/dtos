"""Prepare disposable, synthetic cache/projection inputs before observation.

Run from an unchanged DTOS checkout, normally with /evidence mounted as a
disposable writable directory. This performs no HTTP/provider operations.
Neither catalog shape nor catalog byte size is asserted to reproduce Granite.
"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def raw_identity(pid, index, position, *, name=None, nfl_team=None, active=False):
    """A declared synthetic source-shaped identity, with normal typed fields."""
    first, last = f"Fixture{index}", "Identity"
    return {
        "player_id": pid, "id": pid, "first_name": first, "last_name": last,
        "full_name": name or f"{first} {last}", "position": position,
        "fantasy_positions": [position], "team": nfl_team,
        "active": active, "status": "Active" if active else "Inactive",
        "age": 21 + index % 21, "birth_date": f"{1985 + index % 21}-05-12",
        "birth_city": "Disposable Fixture City", "birth_state": "TX",
        "birth_country": "United States", "height": str(68 + index % 12),
        "weight": str(175 + index % 110), "number": index % 99 + 1,
        "years_exp": index % 18, "college": "Synthetic Fixture University",
        "high_school": "Disposable Fixture High School", "search_rank": index,
        "search_first_name": first.lower(), "search_last_name": last.lower(),
        "search_full_name": f"{first} {last}".lower(), "hashtag": f"#{first}{last}-NFL-{pid}",
        "depth_chart_order": 1 + index % 5 if active else None,
        "depth_chart_position": position if active else None,
        "injury_status": None, "injury_body_part": None, "injury_notes": None,
        "injury_start_date": None, "practice_participation": None,
        "practice_description": None, "team_changed_at": None,
        "news_updated": None, "oddsjam_id": None, "pandascore_id": None,
        "espn_id": 100000 + index, "yahoo_id": 200000 + index,
        "gsis_id": f"FIX-{index:08d}", "fantasy_data_id": 300000 + index,
        "sportradar_id": f"fixture-source-{index:024d}",
        "rotowire_id": 400000 + index, "rotoworld_id": 500000 + index,
        "swish_id": None, "stats_id": 600000 + index,
        "metadata": {
            "fixture_only": True, "rookie_year": str(2005 + index % 22),
            "provider_ids": {
                provider: f"fixture-{provider}-{index:012d}"
                for provider in ("sleeper", "espn", "gsis", "yahoo", "sportradar", "rotowire",
                                 "rotoworld", "fantasy_data", "pff", "stats", "stats_global", "opta")
            },
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("/evidence"))
    parser.add_argument("--catalog-players", type=int, default=12000)
    parser.add_argument("--projection-extra", type=int, default=1000)
    args = parser.parse_args()
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=True)
    scratch = root / "preparation-scratch"
    scratch.mkdir(exist_ok=True)
    database = root / "projections.sqlite3"
    if database.exists():
        raise RuntimeError("Use a fresh disposable output directory; do not overwrite a prior projection store")
    for key, filename in {
        "CACHE": "cache.json", "METADATA_DB": "metadata.sqlite3",
        "INTELLIGENCE_CHECKPOINT": "intelligence.sqlite3", "FOIS_DB": "fois.sqlite3",
        "HISTORY_DB": "history.sqlite3", "ACCOUNT_DB": "accounts.sqlite3",
    }.items():
        os.environ[f"DTOS_{key}_FILE"] = str(scratch / filename)
    os.environ.update(
        DTOS_PROJECTION_DB_FILE=str(database), DTOS_DURABLE_HISTORY_REQUIRED="0",
        DTOS_HISTORY_STORAGE_ROOT=str(scratch), DTOS_SLEEPER_SEASON_CACHE_ROOT=str(scratch / "seasons"),
        SLEEPER_BASE_URL="http://127.0.0.1:9/v1",
    )
    sys.path.insert(0, str(Path.cwd()))
    from tests.test_multileague_projection_compatibility import MultiLeagueProjectionTests
    from src.core.projection_intelligence.service import ProjectionService
    from src.core.intelligence.team_strength import prepare_for_data

    positions = ("QB", "RB", "WR", "TE", "K", "DEF")
    catalog = {
        f"fixture-unowned-{i:05d}": raw_identity(f"fixture-unowned-{i:05d}", i, positions[i % 6])
        for i in range(args.catalog_players)
    }
    profile = {
        "scope": "Preparation only; synthetic disposable league/publication data, not Granite contents or live acceptance.",
        "target_cache_bytes_reference": 23048708, "catalog_identities": len(catalog),
        "catalog_fields": sorted(next(iter(catalog.values()))),
        "catalog_distribution": dict(Counter(row["position"] for row in catalog.values())),
        "catalog_shape_limitations": [
            "Typed source-shaped synthetic fields and provider identifiers; no claim that field density reproduces a real Sleeper catalog.",
            "All unowned catalog records are inactive; current/future projections are only published for owned players plus the declared rich-publication subset.",
            "Catalog identities are attached after canonical preparation; missing rows remain unknown, not zero, and do not fabricate provider evidence.",
            "File sizes approximate the reported cache scale, not a reconstruction of its private contents.",
        ],
        "weeks": [8, 9], "variants": [],
    }
    defense_ids = ("BUF", "CAR", "CHI", "CLE", "DAL", "DEN", "DET", "GB", "HOU", "IND", "JAX", "KC")
    for is_superflex in (False, True):
        fixture = MultiLeagueProjectionTests("test_complete_one_qb_source_to_team_and_package_impact")
        fixture.setUp()
        try:
            data = fixture.data
            prefix = "sf" if is_superflex else "qb"
            mapping = {}
            for team in data["teams"]:
                for player in team["players"]:
                    old = player["id"]
                    mapping[old] = defense_ids[team["roster_id"] - 1] if player["position"] == "DEF" else f"fixture-{prefix}-{old}"
                    player["id"] = mapping[old]
                    player["roster_slot"] = "Starter" if int(old.split("-")[1]) < 10 else "Bench"
                    player["name"] = f"{prefix.upper()} roster {old}"
                team["starters"] = [p["id"] for p in team["players"] if p["roster_slot"] == "Starter"]
                team["owner_id"] = f"fixture-{prefix}-owner-{team['roster_id']}"
            feed = [deepcopy(row) | {"player_id": mapping[row["player_id"]]} for row in fixture.feed]
            if is_superflex:
                data["league"]["roster_positions"] = ["QB", "RB", "RB", "WR", "WR", "FLEX", "FLEX", "WRRB_FLEX", "REC_FLEX", "SUPER_FLEX", *(["BN"] * 10)]
                data["league"]["scoring_settings"].update(bonus_rec_te=1, bonus_rec_rb=.5)
                for team in data["teams"]:
                    pid = f"fixture-sf-{team['roster_id']}-extra"
                    team["players"].append(dict(id=pid, name="SF fixture extra WR", position="WR", fantasy_positions=["WR"], team="BUF", status="Active", roster_slot="Bench"))
                    feed.append(dict(player_id=pid, season=2026, week=8, player={"position":"WR", "fantasy_positions":["WR"]}, stats={"rec_yd":100, "rec":5}))
                    # Keep the disposable submitted SF lineup legal as well:
                    # dedicated K/DEF are rostered bench assets, not SF starters.
                    starter_ids = [mapping[f"{team['roster_id']}-{i}"] for i in (0, 1, 2, 3, 4, 5, 6, 7)] + [pid, mapping[f"{team['roster_id']}-10"]]
                    for player in team["players"]:
                        player["roster_slot"] = "Starter" if player["id"] in starter_ids else "Bench"
                    team["starters"] = starter_ids
            # Ten starters plus ten ordinary reserves; two IR and two taxi occupants.
            # Genuine published zero reserves cannot replace a supported higher starter.
            for team in data["teams"]:
                bench = sum(p["roster_slot"] == "Bench" for p in team["players"])
                for j in range(10 - bench + 4):
                    slot = "Bench" if j < 10 - bench else "IR" if j < 12 - bench else "Taxi"
                    pos = ("QB", "RB", "WR", "TE")[j % 4]
                    pid = f"fixture-{prefix}-{team['roster_id']}-depth-{j}"
                    player = dict(id=pid, name=f"Fixture {prefix} reserve {team['roster_id']}/{j}", position=pos, fantasy_positions=[pos], team="BUF", status="IR" if slot == "IR" else "Active", injury_status="IR" if slot == "IR" else None, roster_slot=slot)
                    team["players"].append(player)
                    feed.append(dict(player_id=pid, season=2026, week=8, player={"position":pos,"fantasy_positions":[pos]}, stats={"pass_yd":0,"rush_yd":0,"rec_yd":0,"rec":0}))
            owned = {p["id"]:p for team in data["teams"] for p in team["players"]}
            data["players"] = deepcopy(owned)
            data["league"]["settings"].update(reserve_slots=10, taxi_slots=6)
            for rich in (False, True):
                selected = deepcopy(data)
                league_id = ("superflex" if is_superflex else "oneqb") + ("-rich" if rich else "-rostered")
                selected["league"]["league_id"] = league_id
                if rich:
                    selected["players"].update({pid:deepcopy(row) for pid,row in list(catalog.items())[:args.projection_extra]})
                service = ProjectionService(database, league_id=league_id)
                current = deepcopy(feed)
                future = [deepcopy(row) | {"week":9} for row in feed if is_superflex or row["player_id"] != defense_ids[0]]
                for row in future:
                    row["stats"] = {key:value * .9 for key,value in row["stats"].items()}
                snapshot = service.publish_horizon({8:current, 9:future}, data=selected, league_id=league_id, season=2026, current_week=8)
                with patch("services.global_evidence.retained_global_evidence", return_value=None):
                    strength = prepare_for_data(service, selected)
                expected = 135.0 if is_superflex else 115.0
                current_totals = {rid:row["weekly"][8]["optimal"]["projected_points"] for rid,row in strength["teams"].items()}
                assert set(current_totals.values()) == {expected}, current_totals
                if not is_superflex:
                    assert strength["teams"]["1"]["weekly"][9]["optimal"]["projected_points"] is None
                    assert "DEF" in strength["teams"]["1"]["weekly"][9]["optimal"]["unsupported_slots"]
                # Identity catalog is present in the cached source, while publication
                # scope remains explicit and immutable. Never generate on restoration.
                selected["players"] = deepcopy(catalog)
                for i,(pid,row) in enumerate(owned.items()):
                    selected["players"][pid] = raw_identity(pid, args.catalog_players+i, row["position"], name=row["name"], nfl_team=row["team"], active=row["status"] == "Active")
                selected["normalized_players"] = {pid:{"player_id":pid,"name":row.get("full_name"),"position":row["position"],"nfl_team":row["team"],"availability":"active" if row["active"] else "inactive"} for pid,row in selected["players"].items()}
                selected["market_data"] = {}
                selected["transactions"] = []
                selected["traded_picks"] = []
                selected["season"] = 2026
                payload = {"data":selected,"last_sync":datetime.now(timezone.utc).isoformat()}
                filename = ("superflex" if is_superflex else "oneqb") + ("" if rich else "-rostered") + ".json"
                raw = encoded(payload)
                if len(raw) >= 64 * 1024**2:
                    raise RuntimeError("Prepared cache exceeds existing retention size policy")
                (root/filename).write_bytes(raw)
                profile["variants"].append({"filename":filename,"league_id":league_id,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"cache_target_ratio":len(raw)/profile["target_cache_bytes_reference"],"source_players":len(selected["players"]),"rostered_players":len(owned),"projected_publication_players":len(snapshot["players"]),"extra_missing_projection_rows":args.projection_extra if rich else 0,"projection_generation":snapshot["projection_snapshot_id"],"scoring_profile_id":snapshot["scoring_profile_id"],"scoring":selected["league"]["scoring_settings"],"slots":selected["league"]["roster_positions"],"current_optimal_points":current_totals,"future_supported_franchises":sum(row["weekly"][9]["available"] for row in strength["teams"].values()),"note":"Week 9 omits only first one-QB franchise DEF source row; missing remains unknown. Extra bench zero projections are explicit fixture evidence."})
                del service, selected, snapshot, strength, payload, raw
        finally:
            fixture.doCleanups()
    profile["projection_database_bytes"] = database.stat().st_size
    (root/"profile.json").write_text(json.dumps(profile,indent=2)+"\n")
    print(json.dumps({"scope":profile["scope"],"variants":[{k:r[k] for k in ("filename","bytes","source_players","rostered_players","projected_publication_players","cache_target_ratio")} for r in profile["variants"]],"database_bytes":profile["projection_database_bytes"]},indent=2))


if __name__ == "__main__":
    main()
