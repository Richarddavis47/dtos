# Franchise transaction history — independent acceptance

Source acceptance record and independent verification plan. Mandatory hosted outcomes are established by the guarded publisher's VALIDATION.json and original source-bound artifacts; final publication/deployment records establish production status. This file alone makes no deployment claim.

Baseline: v1.22.13/build2228, 6b43bfa183ed9a2023ecb59247c8831da3c4b1dd, tree 0764486d9440d39438a615ef301ddafe3a30a7fd. Candidate: 63efcdde1573f9cbf2bc5b2bd02984d3d477064f, tree e044d42def632a55f56180adfaf9330d632c0f37. PR318; intended v1.22.14/build2229.

The existing Franchise History now exposes supported transactions and observed draft selections. Calendar age no longer establishes complete coverage. Completed movements require explicit completed status and compatible, readable source facts. Pending/rejected/failed/unknown or malformed records remain separately qualified. Exact pick originals are independent of present owner or selecting franchise. Ownership is an observed season relationship, not a verified transaction-time actor. FOIS remains RETAINED / NOT REVALIDATED.

Evidence scope: Day Traders and Arkham use the repository's explicitly partial October12 Sleeper captures, not fresh live histories. Synthetic linked seasons separately demonstrate complete-empty, unknown, ownership change, malformed input, source changes and cache checkpoint cases. The original baseline console survives; original baseline HTML/report were overwritten by a probe and were subsequently recreated from the exact baseline source, labeled accordingly. No production league entry, discovery, sync, FOIS rebuild or saved-state mutation was performed.

Acceptance checklist:
1. Check deployed identity, merged tree and immutable attachment checksums against this source.
2. Inspect existing Franchise History in Day Traders and a second authorized league without initiating a source refresh. Verify partial/unknown seasons do not say no activity.
3. Match one completed trade/waiver and an observed selection to retained source IDs/seasons. A draft observation does not establish full draft coverage.
4. Inspect an exact moved pick whose original franchise differs from its owner. Across owner changes or missing league links, verify qualified attribution and no backdated current-manager credit.
5. Pending/rejected records must remain separate, without completed movement/dossier links. Retained FOIS qualification must remain visible.
6. At 320x432,375x667,390x844 and desktop check wrapping, keyboard disclosure/focus and touch targets. Chromium emulation is tested; physical Safari remains unverified.

No source history is reconstructed from current rosters. Existing transaction records may survive eviction in compact checkpoints while acquired-week metadata remains unavailable. Partial retained records never establish complete or empty history. Cleanup observations do not establish indefinite leak freedom.

Fixture lifecycle correction: a superseded4,106-test local run had two late Trade browser subtest errors caused by real memory deferral. Per-viewport account/source/browser/driver ownership and release of in-process HTTP response cycles resolved the matched845MiB held-RSS control without changing any original workflow assertion, timeout, memory guard or production behavior. Earlier unsuccessful fixture attempts remain separate.

Local exact-source acceptance:4,107 tests and all ten canonical gates passed in the clean writable Python3.14.3 checkout, UID1000, enforced2GiB/no swap/two CPUs/network none. Original568-entry canonical payload manifest verified; cgroup peak2,007,875,584bytes, final202,018,816bytes, no OOM/OOM-kill, process cleanup passed. Focused112 tests passed197.417s; five exact-source metadata-only admission cases passed. The complete original console and byte-equivalent400k line-boundary parts are included. These fixture measurements are not a production worst-case profile or proof of indefinite leak freedom.
