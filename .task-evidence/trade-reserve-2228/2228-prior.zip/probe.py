import sys; sys.path.insert(0,"/app")
import json
from pathlib import Path
from tests.test_trade_lineup_detail import TradeLineupDetailTests
from services.trade_lineup_detail import lineup_detail_view
from services.trade_decision import decision_context
f=TradeLineupDetailTests(); f.setUp()
try:
    # Additional unpriced bench identity retains a legal starting lineup while
    # its absent projection prevents an exact full reserve comparison.
    p={'id':'1-unknown','name':'Uncovered bench receiver','full_name':'Uncovered bench receiver','position':'WR','fantasy_positions':['WR'],'status':'Active'}
    f.data['players'][p['id']]=p
    f.data['teams'][0]['players'].append(p)
    f.f.publish()
    e=f.evaluate(); v=lineup_detail_view(e)
    out=Path('/evidence/before'); out.mkdir(exist_ok=True)
    (out/'evaluation.json').write_text(json.dumps(e,indent=2,default=str))
    (out/'rendered.html').write_text(e['explanation_html'])
    (out/'detail.json').write_text(json.dumps(v,indent=2,default=str))
    print(json.dumps({'active':v['sides']['active'][8]['phases'],'partner':v['sides']['partner'][8]['phases'],'summary':decision_context(e)['your_side_summary']},indent=2))
finally: f.doCleanups()
