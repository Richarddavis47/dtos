import sys; sys.path.insert(0,'/app')
from tests.test_trade_lineup_detail import TradeLineupDetailTests
from services.trade_lineup_detail import lineup_detail_view
import json
f=TradeLineupDetailTests(); f.setUp()
try:
 f.f.test_superflex_without_dedicated_te_preserves_legal_scoring(); e=f.evaluate();v=lineup_detail_view(e)
 for s in ('active','partner'):
  for p in ('pre','post'):
   r=e['multi_horizon_impact']['sides'][s]['weekly'][8][p]['reserve_capacity']
   print(s,p,json.dumps(r),json.dumps(v['sides'][s][8]['phases'][p].get('reserve_evidence')))
finally: f.doCleanups()
