"""Flatten only the validated local runtime to avoid VFS layer duplication."""
import json
from pathlib import Path
import subprocess

def inspect(name):
    return json.loads(subprocess.check_output(['docker','image','inspect',name],text=True))[0]

original=inspect('dtos-canonical314:2223')
assert original['Id']=='sha256:ce7784605e99a083dc4f0c6d898398b392b8f9bd5409f703370f1d2b9d2237c6'
config=original['Config']
assert not any(any(s in item.split('=',1)[0].upper() for s in ('TOKEN','SECRET','PASSWORD','PROXY')) for item in config['Env'])
name='dtos-2223-runtime-export'
subprocess.run(['docker','create','--name',name,'dtos-canonical314:2223'],check=True,capture_output=True)
args=['docker','import']
for item in config['Env']:args+=['--change','ENV '+item]
args+=['--change','WORKDIR '+config['WorkingDir'],'--change','CMD '+json.dumps(config['Cmd']),'-','dtos-canonical314-flat:2223']
exporter=subprocess.Popen(['docker','export',name],stdout=subprocess.PIPE)
try:
    imported=subprocess.run(args,stdin=exporter.stdout,check=True,capture_output=True,text=True)
    exporter.stdout.close()
    assert exporter.wait()==0
    result=inspect('dtos-canonical314-flat:2223')
    assert result['Config']['Env']==config['Env']
    assert result['Config']['WorkingDir']==config['WorkingDir'] and result['Config']['Cmd']==config['Cmd']
    Path('/workspace/2223-focused314/flattened-runtime.json').write_text(json.dumps(dict(original=original['Id'],flattened=result['Id'],layers=result['RootFS']['Layers'],environment_keys=[x.split('=',1)[0] for x in config['Env']],scope='Identical exported runtime filesystem and image environment; local validation only, no production changes'),indent=2))
    print('Runtime flattened; original and imported filesystem/configuration retained for verification',result['Id'])
finally:
    subprocess.run(['docker','rm',name],check=True,capture_output=True)
