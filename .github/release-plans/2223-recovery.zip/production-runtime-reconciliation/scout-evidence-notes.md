# DTOS build 2223 independent acceptance notes

Candidate: a76da620c17338e4c5ee0a007829b56bbcf845f4
Tree: 9acf0b605c79e1d5091adc706b0fe23e45805f29
Existing PR:312. Target:v1.22.8/build2223.
This document is evidence preparation, not a release-success certificate. Final publication and production identity must be verified separately.

The original workspace resumed intact at7e3ad11d4de501ecc810746f0def48d7d38e0190. Five uncommitted files were snapshotted with per-file hashes and a patch before reconciliation. Nothing was reconstructed. The snapshot and all prior failed/incomplete attempts remain in the recovery archive.

## Resource contract

Trade retains256MiB working allowance plus128MiB safety. Current container evidence is required; no host-free-memory fallback. Conditional reclaim credit uses only half of verified clean inactive file pages, capped384MiB, excluding dirty/writeback/shared/unevictable bytes. Raw measurements remain unchanged. FOIS retains its independent768MiB raw reserve.

One nonqueued Trade lease covers preparation within the operation, full evaluation and serialization. Conflicting heavy FOIS/Sleeper/history/Market work cannot overlap it. Explicit recovery may retire an idle FOIS executor, expire already-expired bounded entries and trim unused allocator pages. It never invalidates active publications, forces a source refresh or starts automatic discovery. Cancellation/timeout keep ownership until real evaluation exits. The server deadline is105seconds. The execution model remains an in-process thread; an idle executor thread is not detached evaluation or live retained work.

## Final hosted constrained proof

The original clean-source artifact13189802505 is SHA256710a62eab43cc1da18a099ee3c3ade760d645eb54c31e165adf44a6039e35d53. Original ZIP bytes, internal checksums, source/tree and cleanup were verified.

Healthy and recovered searches completed180full evaluations each in29.328s and19.133s with identical business digests and zero qualified offers. These are cold/warm fixture observations, not a universal speed improvement. A completed zero-result search is different from deferral.

Anonymous-heavy pressure deferred before evaluation. Relieving pressure allowed completion. A separate clean-file pressure case completed180evaluations while file memory fell805654528→674234368bytes with valid contents. Raw lifetime peak was2147483648bytes, with no OOM/kill. Model-demand ballast146800640bytes and other harness ballast920018944bytes are identified separately; neither is subtracted to claim production headroom. Raw kernel reclaim pressure remains disclosed.

Actual cancellation started one evaluation and drained it before releasing ownership. The156.235ms observation includes150ms of post-cancellation stability observation. Actual timeout and failure paths also released ownership. Scratch was absent and the Trade lease available after cleanup.

The one-QB HTTP control uses twelve disposable franchises and starting slots QB/RB/RB/WR/WR/TE/FLEX/FLEX/K/DEF. Both sides retain legal optimal pre/post lineups with compatible week8/scoring evidence. No K/DEF Market quote is fabricated. This is Granite-shaped fixture evidence, not current live Granite acceptance.

Eighty overlapping liveness samples recorded maximum177.603ms ASGI server duration and331.550ms client duration. Profile: actual2GiB/twoCPU/networknone. These observations do not establish production latency or sustained capacity clearance.

## Phone and validation recovery

The old43e canonical run completed3988tests with one320px picker failure, zero errors and no OOM. Its553manifest payload hashes and original archive digest are verified. The passing older localPython3.12 run was not substituted for productionPython3.14 acceptance.

Matching3.14/Chromium156 reproduced944.015625px exactly: purpose-tab widths130.42+132.31px plus8px gap exceeded262px, wrapping onto two rows. The small-phone13px control scale retains44px targets and one row. Concise readiness copy retains prepared/incompatible projection and ready/deferred/unknown capacity distinctions. No warning is clipped or line-clamped. Original900px assertion remains; corrected320px picker883.80px. Other requested widths:375→865.61px,390→846.11px,desktop→819.42px.

Focused19controls passed. Subsequent final6controls passed, including three repeated browser-history journeys, the original picker workflow and24readiness/viewport combinations. Browser fixtures wait for the same required pick/team path or exact preserved Market query before the original assertion. No navigation retries, forced destinations or application Back changes were added. The original asynchronous URL failures and overly strict query-excluding wait errors remain retained.

Other original failures remain distinct: unknown bare-runner cgroup telemetry correctly deferred normal fixtures; actual2GiB isolation restored real execution. Fresh readiness timestamps are separately validated without dropping workspace/preference comparisons. Runner-owned output parents prevent root-owned screenshot directories from blocking preparation. No admission reserve or assertion was relaxed.

## Preservation and live handoff

No Market/Custom formula, saved rank/order/revision/flag, exact pick, projection, legal-lineup calculation, bilateral threshold, historical/FOIS grade, permanent goal or production preference was changed. No production Relative activation, submitted lineup or trade occurred. Ordinary navigation starts zero discovery requests in the controlled journeys. Keyboard/touch/no-overflow controls cover320x432,375x667,390x844 and desktop. Controlled Chromium is not physical Safari.

Configured operational inspection returned401; the associated Browser app execution tool was unavailable. These are specific access limitations, not proof that all browser access is impossible. Live Granite recovery remains unverified. Do not force production work to demonstrate success.

After verified deployment, Scout should confirm version/commit, authorized Granite franchise context, compatible publication and fresh resource readiness. If safe, perform at most one bounded unseeded search; admission rechecks atomically. Preserve package, exact picks, mode and temporary strategy; do not save a goal/ranking/method. No qualifying recommendation is required. Record completion, capacity deferral and failure separately. If unsafe, preserve the workspace and stop without looped retries. Missing source evidence must not be repaired by changing picks or inventing projections.
