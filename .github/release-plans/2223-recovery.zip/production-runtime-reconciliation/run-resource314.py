"""Sequential production-Python resource proof; no app code or guard changes."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

root=Path('/workspace/2223-py314-resource')
root.mkdir(exist_ok=True)
(root/'fixture').mkdir(exist_ok=True)
(root/'evidence').mkdir(exist_ok=True)
source=Path('/workspace/dtos')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert head=='a76da620c17338e4c5ee0a007829b56bbcf845f4'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
cache=Path('/workspace/2223-focused314/runtime314-layer-cache-id.txt').read_text().strip()
assert re.fullmatch('[a-f0-9]{64}',cache)
runtime='/var/lib/docker/vfs/dir/'+cache
image=json.loads(subprocess.check_output(['docker','image','inspect','dtos-canonical314-flat:2223'],text=True))[0]
assert image['Id']=='sha256:2c9de92bf8e05a79587f6edba94052cf614c984a5cb81a62613871388cd6533e'
assert not any(any(s in v.split('=',1)[0].upper() for s in ('TOKEN','SECRET','PASSWORD','PROXY')) for v in image['Config']['Env'])
invocations=[]
for phase in ['preparation','execution']:
    args=['docker','run','--name','dtos-2223-resource314-'+phase,'--rm','--init','--memory=2g','--memory-swap=2g','--cpus=2','--network=none']
    for name in ['usr','bin','lib','lib64','etc','opt','var','root','run']:
        args+=['--mount',f'type=bind,src={runtime}/{name},dst=/{name},readonly']
    for item in image['Config']['Env']:args+=['--env',item]
    args+=['--env','DTOS_EXPECTED_HEAD='+head,'--env','GIT_CONFIG_COUNT=1',
           '--env','GIT_CONFIG_KEY_0=safe.directory','--env','GIT_CONFIG_VALUE_0=/app',
           '--volume',str(source)+':/app:ro','--volume',str(root)+':/proof','--workdir','/app',
           'dtos-canonical-runtime-mounts:2223','/usr/local/bin/python','-c',
           'import json,sys; print("DTOS_RUNTIME "+json.dumps({"python":sys.version}),flush=True); from tools.validation.trade_resource_recovery import main; main()',
           '--fixture','/proof/fixture']
    args+=['--prepare'] if phase=='preparation' else ['--output','/proof/evidence']
    invocations.append(dict(phase=phase,command=args))
    (root/'invocation.json').write_text(json.dumps(dict(head=head,runtime=image['Id'],invocations=invocations,
        scope='Sequential disposable2GiB/twoCPU/networknone containers; preparation excluded from application lifetime peak. Same frozen source and unchanged proof. Not live Granite or sustained capacity clearance.'),indent=2))
    with (root/'evidence'/('preparation.log' if phase=='preparation' else 'raw.log')).open('w') as log:
        subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
result=json.loads((root/'evidence/result.json').read_text())
assert result['passed'] and result['complete'] and result['working_tree_clean']
assert result['head']==head
(root/'evidence/SHA256SUMS').write_text(''.join(hashlib.sha256((root/'evidence'/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in ['result.json','raw.log','preparation.log']))
print('Production-Python resource execution completed with clean exact source.')
