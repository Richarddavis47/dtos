"""Exact production runtime through read-only mounts; unchanged validation gates."""
import json
from pathlib import Path
import re
import subprocess

source=Path('/workspace/2223-py314-final/source')
cache=Path('/workspace/2223-focused314/runtime314-layer-cache-id.txt').read_text().strip()
assert re.fullmatch('[a-f0-9]{64}',cache)
runtime='/var/lib/docker/vfs/dir/'+cache
image=json.loads(subprocess.check_output(['docker','image','inspect','dtos-canonical314-flat:2223'],text=True))[0]
assert image['Id']=='sha256:2c9de92bf8e05a79587f6edba94052cf614c984a5cb81a62613871388cd6533e'
assert not any(any(s in v.split('=',1)[0].upper() for s in ('TOKEN','SECRET','PASSWORD','PROXY')) for v in image['Config']['Env'])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert head=='a76da620c17338e4c5ee0a007829b56bbcf845f4'
args=['docker','run','--name','dtos-2223-local-final314','--rm','--init','--memory=2g','--memory-swap=2g','--cpus=2','--network=none']
for name in ['usr','bin','lib','lib64','etc','opt','var','root','run']:
    args+=['--mount',f'type=bind,src={runtime}/{name},dst=/{name},readonly']
for item in image['Config']['Env']:args+=['--env',item]
args+=['--env','NODE_OPTIONS=--max-old-space-size=256','--env','DTOS_EXPECTED_HEAD='+head,
       '--volume',str(source)+':/app','--volume',str(source/'.validation/canonical-release')+':/output',
       '--volume',str(source/'.validation/canonical-fixture')+':/fixture','--workdir','/app',
       'dtos-canonical-runtime-mounts:2223','/usr/local/bin/python','/output/runner.py']
Path('/workspace/2223-py314-final/invocation.json').write_text(json.dumps(dict(head=head,
    original_runtime='sha256:ce7784605e99a083dc4f0c6d898398b392b8f9bd5409f703370f1d2b9d2237c6',
    flattened_runtime=image['Id'],command=args,
    scope='Same runtime binaries, package versions and image environment verified; read-only reuse avoids VFS duplication. Actual2GiB/twoCPU/networknone and8GiB real-disk scratch preflight unchanged.'),indent=2))
raise SystemExit(subprocess.run(args).returncode)
