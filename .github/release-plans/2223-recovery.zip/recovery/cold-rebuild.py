import asyncio, json, threading, time
from pathlib import Path
from unittest.mock import patch
import dtos_app
from services import trade_intelligence as trade
from src.core.projection_intelligence.service import ProjectionService
from src.core.data_platform import data_platform
from src.core.data_platform.storage import SnapshotWarehouse
from src.platform.trade_execution import run_trade_operation,observe_memory
root=Path('/evidence');fixture=root/'fixtures/source-shape';data=json.loads((fixture/'data.json').read_text())
for x in data['team_strength']['teams'].values():x['weekly']={int(k):v for k,v in x['weekly'].items()}
reader=ProjectionService(fixture/'projections.sqlite3');samples=[];stop=threading.Event()
def watch():
 while not stop.wait(.01):samples.append(observe_memory())
thread=threading.Thread(target=watch);thread.start();initial=observe_memory();started=time.monotonic()
async def main():
 def work():
  r=trade.generate_trade_workflow(data,dict(active_roster_id=1,workflow='recommended',strategy='REBUILD'))
  return r,json.dumps(r,default=str)
 with patch.object(trade,'_trade_projection_service',return_value=reader),patch.object(data_platform,'warehouse',SnapshotWarehouse()):r,encoded=await run_trade_operation(work)
 report=dict(scope='Fresh cold Rebuild; no previous Trade evaluation in this container. Separate enforced2GiB cgroup; colocated with local validation, timing is not a speed comparison.',seconds=time.monotonic()-started,initial=initial,peak_raw=max(x['cgroup_current_bytes'] for x in samples),incremental_peak=max(x['cgroup_current_bytes'] for x in samples)-initial['cgroup_current_bytes'],final=observe_memory(),evaluations=r['search_evidence']['full_evaluations'],response_bytes=len(encoded),qualified=r['count'])
 (root/'cold-rebuild-final-source.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
try:asyncio.run(main())
finally:stop.set();thread.join()
