import asyncio,hashlib,json,threading,time,tempfile,os,gc
from pathlib import Path
from unittest.mock import patch
import psutil
from fastapi.testclient import TestClient
import dtos_app
from services import trade_intelligence as trade
from tests.test_trade_performance import business
from src.core.projection_intelligence.service import ProjectionService
from src.core.data_platform import data_platform
from src.core.data_platform.storage import SnapshotWarehouse
from src.platform import trade_execution as execution
from src.platform.lifecycle import lifecycle_coordinator
from src.platform.memory_reclamation import release_unused_allocator_pages
root=Path('/evidence');fixture=root/'fixtures/source-shape';data=json.loads((fixture/'data.json').read_text())
for row in data['team_strength']['teams'].values():row['weekly']={int(k):v for k,v in row['weekly'].items()}
reader=ProjectionService(fixture/'projections.sqlite3');client=TestClient(dtos_app.app)
client.get('/health/live')
report={'scope':'Actually enforced2GiB disposable source-compatible workloads. File/anonymous ballast is test harness memory, not claimed production headroom. No production Trade invoked.','states':[],'operations':[]}
def observe(label):
 s=execution.observe_memory();s.update(label=label,at=time.monotonic(),processes=[{'pid':p.pid,'ppid':p.ppid(),'rss':p.memory_info().rss} for p in [psutil.Process(),*psutil.Process().children(recursive=True)]],threads=psutil.Process().num_threads(),capacity=execution.assess_memory(s));report['states'].append(s);return s
samples=[];stop=threading.Event()
def sample_loop():
 while not stop.wait(.025):
  m=execution.observe_memory();samples.append({'at':time.monotonic(),'current':m['cgroup_current_bytes'],'anon':m.get('file_accounting',{}).get('file'),'file':m.get('file_accounting',{}).get('file')})
thread=threading.Thread(target=sample_loop,daemon=True);thread.start()
proposal=dict(active_roster_id=1,workflow='recommended',strategy='REBUILD')
def digest(result):return hashlib.sha256(json.dumps(business(result),sort_keys=True,default=str).encode()).hexdigest()
async def run_search(label):
 started=time.monotonic();idx=len(samples)
 def work():
  result=trade.generate_trade_workflow(data,proposal);encoded=json.dumps(result,default=str)
  return result,encoded
 result,encoded=await execution.run_trade_operation(work)
 r={'label':label,'seconds':time.monotonic()-started,'full_evaluations':result['search_evidence']['full_evaluations'],'qualified':result['count'],'state':result['result_state'],'business_digest':digest(result),'response_bytes':len(encoded),'peak_raw_current':max((x['current'] for x in samples[idx:]),default=0)}
 assert r['full_evaluations']==180
 report['operations'].append(r);print(json.dumps(r),flush=True)
 return r['business_digest']
def allocate_to_raw_headroom(mib):
 current=execution.observe_memory()['cgroup_current_bytes'];count=max(0,2147483648-current-mib*execution.MIB);padding=bytearray(count)
 for offset in range(0,len(padding),4096):padding[offset]=1
 return padding
async def health(label):
 started=time.monotonic();r=await asyncio.to_thread(client.get,'/health/live');elapsed=(time.monotonic()-started)*1000;assert r.status_code==200 and elapsed<500;report.setdefault('liveness',[]).append({'label':label,'milliseconds':elapsed})
async def main():
 assert execution.observe_memory()['cgroup_limit_bytes']==2147483648
 observe('prepared_and_server_imported')
 reference=await run_search('healthy_real_180_candidate_search')
 release_unused_allocator_pages();observe('healthy_after_allocator_trim')
 # Unsafe anonymous pressure must not enter the supplied operation at all.
 ballast=allocate_to_raw_headroom(192);observe('unsafe_anonymous_pressure');called=[]
 try:
  await execution.run_trade_operation(lambda:called.append(1))
  raise AssertionError('Unsafe work admitted')
 except execution.TradeSearchDeferred:pass
 assert not called and lifecycle_coordinator.trade_search_available()
 await health('unsafe_pressure');observe('unsafe_deferred_no_worker_started')
 del ballast;release_unused_allocator_pages();observe('pressure_relieved')
 assert await run_search('real_search_after_pressure_relief')==reference
 # Check true cancellation after a bilateral evaluation has actually begun.
 count=0;original=trade.evaluate_trade_request;entered=threading.Event()
 def evaluate(*args,**kwargs):
  nonlocal count
  count+=1;entered.set();return original(*args,**kwargs)
 with patch.object(trade,'evaluate_trade_request',side_effect=evaluate):
  task=asyncio.create_task(execution.run_trade_operation(lambda:trade.generate_trade_workflow(data,proposal)))
  while not entered.is_set():await asyncio.sleep(.005)
  began=time.monotonic();task.cancel()
  try:await task
  except asyncio.CancelledError:pass
  else:raise AssertionError('Cancelled work reported completion')
  finished=count;await asyncio.sleep(.15);assert count==finished and lifecycle_coordinator.trade_search_available();report['actual_cancel']={'evaluations_started':finished,'drained_ms':(time.monotonic()-began)*1000}
 observe('real_cancel_drained')
 with patch.object(execution,'TRADE_TIMEOUT_SECONDS',.3):
  try:await execution.run_trade_operation(lambda:trade.generate_trade_workflow(data,proposal))
  except execution.TradeSearchTimedOut:pass
  else:raise AssertionError('Timeout did not execute')
 assert lifecycle_coordinator.trade_search_available();observe('real_timeout_drained')
 def fail():raise RuntimeError('Synthetic failure')
 try:await execution.run_trade_operation(fail)
 except RuntimeError:pass
 assert lifecycle_coordinator.trade_search_available();observe('failure_released')
 # Conditional file-cache allowance: dirty/writeback must be zero first.
 release_unused_allocator_pages()
 with tempfile.TemporaryDirectory() as tmp:
  path=Path(tmp)/'clean-cache.bin';chunk=b'z'*1024**2
  with path.open('wb') as f:
   for _ in range(768):f.write(chunk)
   f.flush();os.fsync(f.fileno())
  del chunk
  await asyncio.sleep(.25)
  ballast=allocate_to_raw_headroom(64);before=observe('clean_file_cache_pressure')
  assert before['capacity']['admitted'],before['capacity']
  assert before['capacity']['conditional_file_credit_bytes']>0
  index=len(samples)
  def work():
   # Separate model-demand ballast exercises kernel reclaim within the measured
   # 256MiB work allowance; this is not represented as actual engine allocation.
   model_ballast=bytearray(140*execution.MIB)
   for i in range(0,len(model_ballast),4096):model_ballast[i]=1
   result=trade.generate_trade_workflow(data,proposal)
   return digest(result),result['search_evidence']['full_evaluations']
  (value,evaluations)=await execution.run_trade_operation(work);assert value==reference and evaluations==180
  await health('file_cache_pressure');after=observe('file_cache_search_complete')
  during=samples[index:];min_file=min(x['file'] for x in during);assert before['file_accounting']['file']>min_file
  report['file_cache_recovery']={'model_harness_ballast_bytes':140*execution.MIB,'other_harness_ballast_bytes':len(ballast),'file_before':before['file_accounting']['file'],'minimum_file_during':min_file,'raw_peak':max(x['current'] for x in during),'completed_evaluations':evaluations,'content_still_valid':None}
  with path.open('rb') as f:assert f.read(16)==b'z'*16
  report['file_cache_recovery']['content_still_valid']=True
  del ballast;release_unused_allocator_pages()
 observe('all_ballast_released')
 assert not any(execution.observe_memory()['cgroup_memory_events'].get(k) for k in ['oom','oom_kill'])
 report['kernel_peak']=int(Path('/sys/fs/cgroup/memory.peak').read_text());report['complete']=True
try:
 with patch('services.trade_intelligence._trade_projection_service',return_value=reader),patch.object(data_platform,'warehouse',SnapshotWarehouse()):asyncio.run(main())
finally:
 stop.set();thread.join();root.joinpath('pressure-proof-attempt1.json').write_text(json.dumps(report,indent=2,default=str))
 print(json.dumps({'complete':report.get('complete',False),'operations':report['operations'],'last_phase':report['states'][-1]['label']}),flush=True)
