import json,shutil
from pathlib import Path
root=Path('/evidence/fixtures');out=root/'source-shape';out.mkdir(exist_ok=True);d=json.loads((root/'superflex/data.json').read_text());start=len(d['players'])
for i in range(start,12229):
 pid=f'unowned-{i}';d['players'][pid]={'id':pid,'full_name':f'Disposable identity {i}','position':'WR','age':25,'team':'BUF','metadata':{f'field{j}':'fixture-source-shape-value-012345' for j in range(25)}}
 d.setdefault('normalized_players',{})[pid]={'player_id':pid,'name':f'Disposable identity {i}','position':'WR','nfl_team':'BUF','availability':'active'}
p=out/'data.json';p.write_text(json.dumps(d,sort_keys=True));shutil.copyfile(root/'superflex/projections.sqlite3',out/'projections.sqlite3');print(json.dumps({'fixture':'source-shape','identity_population':len(d['players']),'json_bytes':p.stat().st_size,'source':'Synthetic identity records approximate the16MB public NFL identity population; no private production account data.'}))
