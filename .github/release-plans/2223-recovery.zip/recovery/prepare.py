from pathlib import Path
import copy,json,sqlite3
from unittest.mock import patch
from tests.trade_performance_fixture import prepare_fixture
from tests import test_multileague_projection_compatibility as kdef
from src.core.intelligence.team_strength import prepare_for_data
root=Path('/evidence/fixtures');root.mkdir(exist_ok=True)
prepare_fixture(root/'superflex')
f=kdef.MultiLeagueProjectionTests();f.setUp()
try:
 d=f.data;d['league']['league_id']='league-1';d['league'].update(name='Disposable one-QB',total_rosters=12);d['league']['settings'].update(playoff_week_start=15,playoff_teams=6)
 d['players']={};d['teams']=[];payload=[]
 positions=['QB']*3+['RB']*7+['WR']*10+['TE']*4+['K','DEF']
 for rid in range(1,13):
  players=[]
  for i,pos in enumerate(positions):
   pid=f'{rid}-{pos}-{i}';p=dict(id=pid,name='Fixture '+pid,position=pos,fantasy_positions=[pos],team='BUF',status='Active',roster_slot='Taxi' if i in [7,8,9,17,18,19] else 'Bench')
   players.append(p);d['players'][pid]=dict(p,full_name=p['name'],age=23+i%11)
   stats={'QB':{'pass_yd':350 if rid==1 else 240,'pass_td':1},'RB':{'rush_yd':70+i,'rec':2},'WR':{'rec_yd':60+i,'rec':5},'TE':{'rec_yd':50+i,'rec':4},'K':{'fgm':2},'DEF':{'sack':2,'int':1}}[pos]
   payload.append(dict(player_id=pid,season=2026,week=8,stats=stats,player={'position':pos,'fantasy_positions':[pos]}))
  d['teams'].append(dict(roster_id=rid,owner=f'Disposable manager {rid}',team_name=f'Example {rid}',strategy='RETOOL',players=players,picks_owned=[],starters=['0'],wins=rid%7,losses=rid%4))
 d['market_data']={'providers':{'FantasyCalc':{pid:{'value':(100+int(pid.split('-')[-1])%4*50)*12,'confidence':90} for pid,p in d['players'].items() if p['position'] not in ['K','DEF']}}}
 f.service.publish_horizon({w:[dict(p,week=w) for p in payload] for w in range(8,18)},data=d,league_id='league-1',season=2026,current_week=8)
 with patch('services.global_evidence.retained_global_evidence',return_value=None):prepare_for_data(f.service,d)
 p=root/'one-qb';p.mkdir(exist_ok=True);(p/'data.json').write_text(json.dumps(d,sort_keys=True))
 with sqlite3.connect(f.service._database_file) as source,sqlite3.connect(p/'projections.sqlite3') as target:source.backup(target)
 print(json.dumps({'fixtures':['superflex','one-qb'],'one_qb_players':len(d['players']),'one_qb_teams':len(d['teams']),'phase':'fixture preparation only, not application observation'}))
finally:f.doCleanups()
