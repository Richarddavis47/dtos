import asyncio,json,time,threading
from pathlib import Path
from unittest.mock import patch
from services import trade_intelligence as trade
from src.core.request_execution import run_manager_read
from src.core.projection_intelligence.service import ProjectionService
from src.core.data_platform import data_platform
from src.core.data_platform.storage import SnapshotWarehouse
from src.platform.lifecycle import memory_snapshot,lifecycle_coordinator
root=Path('/evidence/fixtures/source-shape');data=json.loads((root/'data.json').read_text())
for x in data['team_strength']['teams'].values():x['weekly']={int(k):v for k,v in x['weekly'].items()}
reader=ProjectionService(root/'projections.sqlite3');entered=threading.Event();finished=threading.Event();count=0;original=trade.evaluate_trade_request
report={'source':'cab3368234b350bf8fb49d30c8788fbb48714c5a','limit':memory_snapshot()['cgroup_limit_bytes'],'scope':'Real baseline generation in disposable2GiB container; no production work'}
def evaluate(*args,**kw):
 global count
 count+=1;entered.set();return original(*args,**kw)
def search():
 try:return trade.generate_trade_workflow(data,dict(active_roster_id=1,workflow='recommended',strategy='REBUILD'))
 finally:finished.set()
async def main():
 task=asyncio.create_task(run_manager_read(search))
 while not entered.is_set():await asyncio.sleep(.005)
 task.cancel();began=time.monotonic()
 try:await task
 except asyncio.CancelledError:pass
 report['worker_finished_when_cancel_returned']=finished.is_set();before=count
 await asyncio.sleep(.2);report['evaluations_at_cancel_return']=before;report['evaluations_after_200ms']=count;report['coordinator_heavy_state_while_abandoned']=lifecycle_coordinator.snapshot()['heavy_work']['state'];assert not finished.is_set() and count>before
 while not finished.is_set():
  assert time.monotonic()-began<90
  await asyncio.sleep(.1)
 report['real_worker_finish_after_cancel_seconds']=time.monotonic()-began;report['final_evaluations']=count;report['memory_after']=memory_snapshot();print(json.dumps(report));Path('/evidence/baseline-cancellation.json').write_text(json.dumps(report,indent=2))
with patch.object(trade,'_trade_projection_service',return_value=reader),patch.object(trade,'evaluate_trade_request',side_effect=evaluate),patch.object(data_platform,'warehouse',SnapshotWarehouse()):asyncio.run(main())
