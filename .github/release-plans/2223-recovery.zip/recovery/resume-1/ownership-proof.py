import json,subprocess
from pathlib import Path
root=Path('/workspace/2223-resumed-final/source/.validation/canonical-fixture/ownership-proof')
root.mkdir(parents=True,exist_ok=False)
(root/'bad').mkdir();(root/'good/fixture').mkdir(parents=True);(root/'good/evidence/browser').mkdir(parents=True)
writer="from pathlib import Path; r=Path('/fixture/ownership-proof'); (r/'bad/evidence/browser').mkdir(parents=True); (r/'bad/evidence/browser/capture').write_text('synthetic'); (r/'good/evidence/browser/capture').write_text('synthetic')"
subprocess.run(['python','/workspace/2223-resumed-final/run-mounted-runtime.py','python','-c',writer],check=True)
try:(root/'bad/fixture').mkdir()
except PermissionError:old_denied=True
else:old_denied=False
assert old_denied
(root/'good/fixture').mkdir(exist_ok=True);(root/'good/evidence/SHA256SUMS').write_text('synthetic')
report={'old_parent_uid':(root/'bad/evidence').stat().st_uid,'fixed_parent_uid':(root/'good/evidence').stat().st_uid,'old_runner_creation_denied':old_denied,'fixed_runner_fixture_and_manifest_creation':True,'scope':'Disposable runner UID 1000 versus default container root; no permission weakening or application changes'}
Path('/workspace/2223-evidence/resume-1/ownership-proof.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
subprocess.run(['python','/workspace/2223-resumed-final/run-mounted-runtime.py','python','-c',"import shutil; shutil.rmtree('/fixture/ownership-proof')"],check=True)
