"""Reuse the exact local image's read-only runtime without VFS duplication.
No driver, privilege, memory, network, source or validator changes.
"""
import json,re,subprocess,sys
from pathlib import Path
folder=Path('/workspace/2223-evidence/resume-1')
cache=(folder/'runtime-layer-cache-id.txt').read_text().strip()
assert re.fullmatch('[a-f0-9]{64}',cache)
runtime='/var/lib/docker/vfs/dir/'+cache
source=Path('/workspace/2223-resumed-final/source')
args=['docker','run','--rm','--init','--memory=2g','--memory-swap=2g','--cpus=2','--network=none']
for name in ['usr','bin','lib','lib64','etc','opt','ms-playwright']:
 args+=['--mount',f'type=bind,src={runtime}/{name},dst=/{name},readonly']
args+=['-v',str(source)+':/app','-v',str(source/'.validation/canonical-release')+':/output','-v',str(source/'.validation/canonical-fixture')+':/fixture','-w','/app','-e','DTOS_EXPECTED_HEAD='+subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'dtos-canonical-runtime-mounts:2223',*sys.argv[1:]]
(folder/'mounted-runtime-invocation.json').write_text(json.dumps({'runtime_image':'sha256:81f8145489622be3328e08f4788042c091a300028967beb17c23dd035237ea47','runtime_layer':cache,'command':args,'scope':'Local validator only; exact runtime files reused read-only, real cgroup/memory/swap/CPU/network controls unchanged'},indent=2))
raise SystemExit(subprocess.run(args).returncode)
