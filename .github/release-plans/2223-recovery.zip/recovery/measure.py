import argparse,json,time,threading,os,gc,tempfile
from pathlib import Path
from unittest.mock import patch
import psutil
from services import trade_intelligence as trade
from src.core.data_platform import data_platform
from src.core.data_platform.storage import SnapshotWarehouse
from src.core.projection_intelligence.service import ProjectionService
from src.core.trade_intelligence.lineup_memo import lineup_store
from src.platform.lifecycle import memory_snapshot
from src.platform.memory_reclamation import release_unused_allocator_pages
p=argparse.ArgumentParser();p.add_argument('fixture');args=p.parse_args();root=Path('/evidence/fixtures')/args.fixture
assert memory_snapshot()['cgroup_limit_bytes']==2147483648
report={'fixture':args.fixture,'source':'cab3368234b350bf8fb49d30c8788fbb48714c5a','scope':'Fresh application observation in enforced2GiB container; fixture preparation occurred in a different container; no production search','phases':[]}
def obs(label):
 s=memory_snapshot();stat=dict(line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines());s['categories']={k:int(stat[k]) for k in ['anon','file','kernel','inactive_file','file_dirty','file_writeback','shmem'] if k in stat};s['label']=label;s['time']=time.monotonic();s['children']=[{'pid':p.pid,'ppid':p.ppid(),'rss':p.memory_info().rss} for p in psutil.Process().children(recursive=True)];s['threads']=psutil.Process().num_threads();s['lineup_cache']=lineup_store.status();report['phases'].append(s);return s
obs('imports_complete')
data=json.loads((root/'data.json').read_text())
for team in data['team_strength']['teams'].values():team['weekly']={int(k):v for k,v in team['weekly'].items()}
reader=ProjectionService(root/'projections.sqlite3')
report['population']={'franchises':len(data['teams']),'rostered_players':sum(len(t['players']) for t in data['teams']),'required_slots':data['league']['roster_positions'],'prepared_generation':reader.snapshot().get('horizon_generation')}
obs('loaded_prepared_source');samples=[];stop=threading.Event()
def watch():
 while not stop.wait(.02):
  s=memory_snapshot();samples.append({'at':time.monotonic(),'cgroup':s['cgroup_current_bytes'],'rss':s['rss_bytes']})
t=threading.Thread(target=watch,daemon=True);t.start();report['runs']=[]
try:
 with patch('services.trade_intelligence._trade_projection_service',return_value=reader),patch.object(data_platform,'warehouse',SnapshotWarehouse()):
  if args.fixture=='one-qb':
   before=obs('evaluation_before');started=time.monotonic();evaluation=trade.evaluate_trade_request(data,dict(active_roster_id=1,partner_roster_id=2,workflow='create',assets_sent=['1-QB-0'],assets_received=['2-QB-0'],strategy='RETOOL'),projection_reader=reader);(Path('/evidence')/'one-qb-evaluation.json').write_text(json.dumps(evaluation,default=str));report['one_qb_evaluation']={'seconds':time.monotonic()-started,'legal':evaluation['evaluation']['legal'],'verdict':evaluation['evaluation']['recommendation'],'impact':evaluation['evaluation']['multi_horizon_impact']};del evaluation;obs('evaluation_after')
  for strategy in ['WIN NOW','RETOOL','REBUILD']:
   before=obs(strategy+'_before');idx=len(samples);started=time.monotonic()
   result=trade.generate_trade_workflow(data,dict(active_roster_id=1,workflow='recommended',strategy=strategy));search_elapsed=time.monotonic()-started
   encoded=json.dumps(result,default=str);search=result['search_evidence'];peak=max([before['cgroup_current_bytes'],*[x['cgroup'] for x in samples[idx:]]]);rss_peak=max([before['rss_bytes'],*[x['rss'] for x in samples[idx:]]]);report['runs'].append({'strategy':strategy,'seconds':search_elapsed,'serialization_bytes':len(encoded),'count':result['count'],'state':result['result_state'],'evaluations':search['full_evaluations'],'packages':search['packages_constructed'],'timings':search['timings_seconds'],'peak_current_bytes':peak,'increment_current_bytes':peak-before['cgroup_current_bytes'],'increment_rss_bytes':rss_peak-before['rss_bytes'],'reuse':search['reuse']})
   obs(strategy+'_returned');del result,encoded,search;obs(strategy+'_references_released');trim=release_unused_allocator_pages();obs(strategy+'_native_trim');report['runs'][-1]['native_trim_supported_result']=trim
   print(json.dumps({'progress':strategy,'fixture':args.fixture,'seconds':search_elapsed,'increment':report['runs'][-1]['increment_current_bytes']}),flush=True)
finally:stop.set();t.join()
gc.collect();obs('after_gc_diagnostic_only');time.sleep(2);obs('idle_2seconds');report['sample_count']=len(samples);report['kernel_peak_bytes']=int(Path('/sys/fs/cgroup/memory.peak').read_text());Path('/evidence/'+args.fixture+'-baseline-measurement.json').write_text(json.dumps(report,indent=2,default=str));print(json.dumps({'fixture':args.fixture,'runs':report['runs'],'kernel_peak':report['kernel_peak_bytes']}))
