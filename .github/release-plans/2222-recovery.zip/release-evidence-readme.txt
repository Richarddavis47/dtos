DTOS build2222 K/DEF compatibility integration evidence
Candidate f01d3778dc938ac29d123747a3e52a5054008283
Tree6725c0ea529f3853ab6112441b1a945bd92e15a7
Production baseline9b33fa45123eafcdac71ee756898dabfe30a8053
Original K/DEF225337446e5fb81b05299afc0869db6b3f07fa5e

The new source replay uses one frozen authorized source snapshot with current rosters/settings and exact2026 Week8 projection records. It is not contemporaneous roster reconstruction, actual DTOS account binding, a live prepared publication or proof of qualified live recommendations. Raw private inputs are excluded; aggregate results and fingerprints are included. Old source values are historical observations, not targets for an updated publication.

Original candidate failures and canceled attempts remain in the included old sanitized archive. That archive's final report reflects its historical hold; it is not the current release status. New attempt-specific results and original hosted artifacts establish combined-source acceptance separately.

The2GiB recovery fixture executes real work, refuses admission under actual pressure, honors retry cooldown and completes real recovery. Its padding and tiny worker are not production headroom or worst-case capacity proof. Raw lifecycle peaks, including2GiB fixture peaks, remain reported. No guard, reserve, pricing, saved rankings or bilateral threshold changed.

Browser captures use disposable fixtures and Chromium emulation, not physical iPhone/Safari. No production user state changed. Authenticated live inspection returned401; the browser connector required reauthentication. Independent live Granite recovery remains unverified.
