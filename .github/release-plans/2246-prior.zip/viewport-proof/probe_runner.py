"""Disposable exact-source resize diagnosis; never a production request."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys
import unittest


OUT = Path('/proof')
PHASE = (OUT / 'phase.txt').read_text().strip()
sys.path.insert(0, str(Path.cwd()))


def source():
    paths = ['static/js/trade_workspace.js', 'static/css/trade_workspace.css',
             'tests/test_recommended_protections_browser.py']
    return dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
                tree=subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
                status=subprocess.check_output(['git', 'status', '--porcelain'], text=True),
                files={name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in paths})


environment = dict(python=platform.python_version(), playwright=importlib.metadata.version('playwright'),
                   memory_max=Path('/sys/fs/cgroup/memory.max').read_text().strip(),
                   memory_swap_max=Path('/sys/fs/cgroup/memory.swap.max').read_text().strip(),
                   cpu_max=Path('/sys/fs/cgroup/cpu.max').read_text().strip(), phase=PHASE)
print(json.dumps(environment), flush=True)
(OUT / (PHASE + '-source.json')).write_text(json.dumps(dict(environment=environment, source=source()), indent=2) + '\n')

if PHASE == 'baseline-probe':
    from tests.test_recommended_protections_browser import RecommendedProtectionBrowserTests

    case = RecommendedProtectionBrowserTests('test_exact_pick_player_and_phone_search_preserve_other_same_round_pick')
    try:
        helper, _fixture, page, requests = case.fixture()
        helper.ready(page, '/trades/recommended')
        case.protect(page, '2029-R1-1')
        case.protect(page, 'a')
        page.set_viewport_size(dict(width=390, height=844))
        page.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))')
        old = page.locator('[data-protected-asset="2029-R1-1"]').element_handle()
        page.evaluate("""() => {
            window.resizeProof = {events: []};
            const snapshot = type => {
                const section = document.getElementById('recommendation-protection-selection');
                window.resizeProof.events.push({type, at: performance.now(), width: innerWidth,
                    mobile: matchMedia('(max-width:760px)').matches, hidden: section.hidden,
                    classes: document.documentElement.className,
                    ids: [...section.querySelectorAll('button[data-protected-asset]')].map(e=>e.dataset.protectedAsset),
                    buttons: [...section.querySelectorAll('button[data-protected-asset]')].map(e=>({
                        id:e.dataset.protectedAsset, connected:e.isConnected,
                        rects:e.getClientRects().length, height:e.getBoundingClientRect().height,
                        display:getComputedStyle(e).display, visibility:getComputedStyle(e).visibility}))});
            };
            new MutationObserver(records => {snapshot('mutation:' + records.length);})
                .observe(document.getElementById('recommendation-protection-list'), {childList:true});
            matchMedia('(max-width:760px)').addEventListener('change', () => snapshot('media-change'));
            addEventListener('resize', () => snapshot('resize'));
            snapshot('before-crossing');
        }""")
        element_state = """e=>({id:e.dataset.protectedAsset, connected:e.isConnected,
            rects:e.getClientRects().length, height:e.getBoundingClientRect().height,
            display:getComputedStyle(e).display, visibility:getComputedStyle(e).visibility})"""
        before = dict(old=old.evaluate(element_state), box=old.bounding_box(), draft=helper.draft(page)['recommendationProtectedAssets'])
        page.set_viewport_size(dict(width=1280, height=900))
        immediate = dict(old=old.evaluate(element_state), old_box=old.bounding_box(),
                         locator_box=page.locator('[data-protected-asset="2029-R1-1"]').bounding_box())
        page.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))')
        current = page.locator('[data-protected-asset="2029-R1-1"]').element_handle()
        settled = dict(old=old.evaluate(element_state), old_box=old.bounding_box(),
                       current=current.evaluate(element_state), current_box=current.bounding_box(),
                       draft=helper.draft(page)['recommendationProtectedAssets'],
                       events=page.evaluate('window.resizeProof.events'))
        case.assertTrue(before['old']['connected'])
        case.assertGreaterEqual(before['box']['height'], 44)
        case.assertFalse(settled['old']['connected'])
        case.assertIsNone(settled['old_box'])
        case.assertTrue(settled['current']['connected'])
        case.assertGreaterEqual(settled['current_box']['height'], 44)
        case.assertEqual(before['draft'], ['2029-R1-1', 'a'])
        case.assertEqual(settled['draft'], before['draft'])
        case.assertTrue(any(e['type'] == 'media-change' for e in settled['events']))
        case.assertTrue(any(e['type'].startswith('mutation:') for e in settled['events']))
        case.assertFalse([r for r in requests if r[0] == 'POST'])
        previous_style = current.get_attribute('style')
        current.evaluate("e=>{e.style.setProperty('min-height','30px','important');e.style.setProperty('height','30px','important');e.style.padding='0';}")
        negative_box = current.bounding_box()
        try:
            case.assertGreaterEqual(negative_box['height'], 44)
        except AssertionError:
            negative = dict(height=negative_box['height'], original_44px_assertion_failed=True)
        else:
            raise AssertionError('The deliberate 30px geometry was not rejected')
        current.evaluate('(e,style)=>style===null?e.removeAttribute("style"):e.setAttribute("style",style)', previous_style)
        case.assertGreaterEqual(current.bounding_box()['height'], 44)
        report = dict(environment=environment, source=source(), before=before, immediate=immediate,
                      settled=settled, negative_control=negative, no_post_requests=True,
                      conclusion='390-to-1280 media repaint detaches the old Remove handle; current same-ID controls retain visible 44px geometry')
        (OUT / 'baseline-probe-result.json').write_text(json.dumps(report, indent=2) + '\n')
        page.screenshot(path=str(OUT / 'baseline-probe-desktop.png'), full_page=True)
        old.dispose()
        current.dispose()
        print(json.dumps(dict(old_handle_connected=settled['old']['connected'], old_box=settled['old_box'],
                              current_height=settled['current_box']['height'], exact_ids=settled['draft'],
                              negative_control=negative, no_post_requests=True)), flush=True)
    finally:
        assert case.doCleanups(), 'Fixture cleanup failed'
elif PHASE == 'corrected-original-test':
    suite = unittest.defaultTestLoader.loadTestsFromName(
        'tests.test_recommended_protections_browser.RecommendedProtectionBrowserTests.'
        'test_exact_pick_player_and_phone_search_preserve_other_same_round_pick')
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(not result.wasSuccessful())
else:
    raise AssertionError('Unknown proof phase')
