# DTOS v1.22.9 / build 2224 — candidate evidence and Scout acceptance

Candidate: c68293907e00d8a58ed8b2447d8b13402509eea9  
Source tree: 9cb55b84816fcd17d8d28580b4b28d0e4f5041aa  
PR: https://github.com/Richarddavis47/dtos/pull/313

Validation verified: local and hosted canonical each completed 4,003 executions and all ten gates with zero failures/skips or OOM events. All twelve required hosted jobs passed; Product executed 579 tests, My Team 255, public/security 361, beginner navigation 158 + 16, and historical timeline 278. The original hosted canonical ZIP and all 563 manifest payloads were verified; local manifest has 561 verified payloads. Counts overlap and are not unique-test totals.

This is sanitized candidate evidence. The eventual merged commit, immutable release, attachment readback and actual production readiness must be verified separately by the guarded publication record. No live Granite recommendation search was performed for this evidence.

## Finding and correction

The reported Granite entry reached a cold secondary runtime and attempted Sleeper sync during active FOIS. The coordinator correctly refused overlap. That scheduling refusal was converted into a source failure and “No supported roster”; a favicon request immediately retried it. At the failure, raw cgroup usage was about 1.488 GB under 2 GiB, with zero OOM events. No resident Granite publication was present. Existing logs do not establish whether its disk cache existed or was compatible.

Secondary league caches were already saved, but only default-league startup restored a cache. The correction reuses an existing compatible retained cache without provider, history, FOIS or Market preparation; preserves freshness labels and independent analytical compatibility; and exposes a distinct waiting-for-capacity response with one explicit retry per minute. Warm requests continue reading local data. Cache readers remain owned through cancellation/shutdown.

JSON week-key restoration additionally fixes a reproduced source-cache → Trade failure: cached pre-trade week “8” could not join newly computed integer week 8. Only the key representation changes. Malformed/ambiguous week identities are rejected; numbers, projections and generations are not altered.

## Memory and execution

The cache admission allowance is max(128 MiB, 16 × serialized bytes) plus 128 MiB safety. An active FOIS generation retains its full existing 512 MiB outstanding working allowance and larger 256 MiB safety margin before cache decoding. During active FOIS the total requirement is cache working allowance + 768 MiB; otherwise it is cache working allowance + 128 MiB. Unknown telemetry fails closed; no file-backed memory is counted as free. Existing FOIS and Trade policies remain byte-identical to production.

The final local Python 3.14.3 proof uses actual 2 GiB, two CPU and network-none enforcement. A separately prepared 17,776,613-byte source-shaped cache restored during a real worker's FOIS lease at adequate headroom. Unsafe pressure deferred before decoding. At approximately 1.562 GB retained pressure, outstanding FOIS commitments also deferred the read; after the lease ended, the read completed while the same harness pressure remained. Worker reaping and unchanged input bytes were verified. A restored one-QB cache completed real HTTP Trade analysis with pre/post QB/RB/WR/TE/FLEX/K/DEF lineups.

Local server liveness samples were 1.735–7.164 ms; hosted resource samples were 1.127–6.408 ms. Client timings are recorded separately. These controlled two-CPU results do not establish external latency or sustained production capacity. Test padding is explicitly identified and is never subtracted to claim production headroom. Fixture file pages may have been cached outside the observer cgroup; raw file/anonymous measurements are retained.

Trade resource corroboration independently completes 180 full evaluations before and after recovery with matching within-run business digests. Cancellation, timeout and scratch/lease cleanup retain their existing real-execution controls. Zero qualified offers remain a legitimate completed result.

## Phone evidence

Chromium keyboard, touch, visible focus, 44+ px targets and no horizontal overflow were verified at 320×432, 375×667, 390×844 and 1280×900. At 320 px the retry button moved from y=398 to y=283, ending at y=349 within the first viewport. Contextual Back is unchanged. This is not physical iPhone/Safari acceptance.

## Preserved scope

No changes to neutral/Custom mathematics, saved rankings/methods/flags/goals, Trade qualification, projection or legal-lineup calculations, exact picks, submitted lineups, historical reconstruction or FOIS grades. Source equality and AST preservation evidence is included. No infrastructure, plan, environment-variable or production preference mutations occurred. Render reads were authorized diagnostic observations, not synthetic stress.

## Prior attempts

Retain original resource fixture-contamination failure, status-adapter failure, JSON-key evaluation failure, preflight/environment errors, superseded raw-current-only proofs and canceled canonical/Product attempts separately. They are not passing completion evidence. All final exact-source local/hosted canonical results, ten gates and twelve hosted jobs passed. The prior attempts remain separate and do not supply final acceptance.

## Smallest safe live acceptance

1. Enter Granite normally; do not force source sync or FOIS rebuilding.
2. Record selected account/franchise, league, season/week, source generation/freshness and one-QB/FLEX/K/DEF compatibility. A saved-data view must remain clearly qualified.
3. Inspect current Trade readiness separately. Prepared projections do not alone prove search capacity.
4. Only when current resource admission permits it, run one bounded normal Trade search. A qualified recommendation is not required for a completed evaluation.
5. Inspect pre/post legal lineups, exact picks, bilateral evidence and final verdict. If entry/search is deferred, preserve context and retry explicitly later; do not force heavy work or repeat it in a loop.

Live Granite recovery, current source completeness and broad capacity remain unverified until this independent acceptance. A cold league with no usable publication still needs preparation; a cold cache may safely wait for FOIS or memory capacity. Warm compatible pages remain available.
