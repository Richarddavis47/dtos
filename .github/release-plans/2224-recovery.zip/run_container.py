import json, subprocess, sys
from pathlib import Path
root=Path('/workspace/2224-evidence'); fixture=root/'fixture'; fixture.mkdir(exist_ok=True)
cache=Path('/workspace/2223-focused314/runtime314-layer-cache-id.txt').read_text().strip()
runtime='/var/lib/docker/vfs/dir/'+cache
image=json.loads(subprocess.check_output(['docker','image','inspect','dtos-canonical314-flat:2223'],text=True))[0]
assert image['Id']=='sha256:2c9de92bf8e05a79587f6edba94052cf614c984a5cb81a62613871388cd6533e'
args=['docker','run','--name','dtos-2224-focused','--rm','--init','--memory=2g','--memory-swap=2g','--cpus=2','--network=none']
for name in ['usr','bin','lib','lib64','etc','opt','var','root','run']: args+=['--mount',f'type=bind,src={runtime}/{name},dst=/{name},readonly']
for item in image['Config']['Env']: args+=['--env',item]
for key,name in {'CACHE':'cache.json','PROJECTION_DB':'projections.sqlite3','METADATA_DB':'metadata.sqlite3','INTELLIGENCE_CHECKPOINT':'intelligence.sqlite3','FOIS_DB':'fois.sqlite3','HISTORY_DB':'history.sqlite3','ACCOUNT_DB':'accounts.sqlite3'}.items(): args+=['--env',f'DTOS_{key}_FILE=/proof/fixture/{name}']
args+=['--env','DTOS_DURABLE_HISTORY_REQUIRED=0','--env','DTOS_HISTORY_STORAGE_ROOT=/proof/fixture','--env','DTOS_SLEEPER_SEASON_CACHE_ROOT=/proof/fixture/seasons','--env','DTOS_FIXTURE_ROOT=/proof/fixture','--env','SLEEPER_BASE_URL=http://127.0.0.1:9/v1','--env','DTOS_LEAGUE_ENTRY_EVIDENCE=/proof/focused/browser','--env','GIT_CONFIG_COUNT=1','--env','GIT_CONFIG_KEY_0=safe.directory','--env','GIT_CONFIG_VALUE_0=/app','--volume','/workspace/dtos:/app:ro','--volume',str(root)+':/proof','--volume','/workspace/2223-py314-resource/fixture/data.json:/input/data.json:ro','--workdir','/app','dtos-canonical-runtime-mounts:2223','/usr/local/bin/python']+sys.argv[1:]
raise SystemExit(subprocess.run(args).returncode)
