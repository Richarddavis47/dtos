from pathlib import Path
import json,subprocess
from tests import test_cold_league_recovery as cold
from src.platform.lifecycle import lifecycle_coordinator
f=cold.ColdLeagueRecoveryTests('test_html_failure_preserves_context_and_exposes_safe_recovery');f.setUp()
root=Path('/proof/browser-baseline');root.mkdir(exist_ok=True);rows=[]
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()=='9acf0b605c79e1d5091adc706b0fe23e45805f29'
lifecycle_coordinator.reserve_fois_generation()
try:
 for w,h in [(320,432),(375,667),(390,844),(1280,900)]:
  with cold.onboarding.PublicOnboardingTests.browser(f,w,h) as page:
   r=page.goto(f.origin+'/',wait_until='networkidle');assert r.status==503
   assert 'No supported roster is ready' in page.locator('body').inner_text()
   button=page.get_by_role('link',name='Try this page again',exact=True)
   rows.append({'viewport':[w,h],'retry':button.bounding_box(),'status':r.status})
   page.screenshot(path=str(root/f'waiting-{w}.png'),full_page=True)
 assert f.source_requests==[]
 (root/'browser.json').write_text(json.dumps({'source_tree':'9acf0b605c79e1d5091adc706b0fe23e45805f29','scope':'Disposable reproduction on the build2223 production source tree; no live account or source work. Source commit is the validated pre-squash head with identical production tree.','viewports':rows},indent=2))
finally:
 lifecycle_coordinator.release_fois_generation();f.doCleanups()
