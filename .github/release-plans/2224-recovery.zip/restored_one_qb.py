from datetime import datetime,timezone
import json,tempfile,subprocess
from pathlib import Path
from unittest.mock import patch
from services import league_preparation as p
from src.core.league_runtime import LeagueRuntime
from tests.test_trade_resource_admission import TradeResourceHTTPTests
f=TradeResourceHTTPTests('test_one_qb_supported_legal_pre_post_and_unchanged_source')
f.setUp()
try:
 with tempfile.TemporaryDirectory() as folder:
  cache=Path(folder)/'cache.json';cache.write_text(json.dumps({'data':f.f.data,'last_sync':datetime.now(timezone.utc).isoformat()}))
  runtime=LeagueRuntime(f.f.data['league']['league_id'])
  with patch.object(p,'league_cache_file',return_value=cache):
   assert p.restore_cached_runtime(runtime,lambda _:None,expected_season=2026)
  f.f.data=runtime.state['data']
  f.test_one_qb_supported_legal_pre_post_and_unchanged_source()
 print(json.dumps({'passed':True,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'scope':'Restored compatible disposable one-QB cache -> HTTP evaluation -> supported pre/post QB/RB/WR/TE/FLEX/K/DEF; unchanged source values. Not live Granite.'}))
finally:
 f.doCleanups()
