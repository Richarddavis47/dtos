import sys; sys.path.insert(0,'/app')
import gc,json,os,platform,statistics,subprocess,time
from pathlib import Path
from copy import deepcopy
from tests.test_trade_lineup_detail import TradeLineupDetailTests
from services.trade_decision import decision_context
from services.trade_lineup_detail import lineup_detail_view
label=sys.argv[1];out=Path('/evidence')/label;out.mkdir(exist_ok=True)
def read(name):
 p=Path('/sys/fs/cgroup')/name
 return p.read_text().strip() if p.exists() else None
records=[];initial=read('memory.current')
for kind in ('one-qb-complete','one-qb-missing-bench','superflex-ineligible-k-def'):
 f=TradeLineupDetailTests();f.setUp()
 try:
  if kind=='one-qb-missing-bench':
   p={'id':'1-unknown','name':'Uncovered bench receiver','position':'WR','fantasy_positions':['WR'],'status':'Active'}
   f.data['players'][p['id']]=p.copy();f.data['teams'][0]['players'].append(p.copy());f.f.publish()
  elif kind.startswith('superflex'):
   f.f.test_superflex_without_dedicated_te_preserves_legal_scoring()
  durations=[];before=deepcopy(f.data)
  for _ in range(10):
   started=time.perf_counter();e=f.evaluate();durations.append(time.perf_counter()-started)
  assert f.data==before
  v=lineup_detail_view(e); context=decision_context(e)
  (out/(kind+'-evaluation.json')).write_text(json.dumps(e,indent=2,default=str))
  (out/(kind+'-detail.json')).write_text(json.dumps(v,indent=2,default=str))
  (out/(kind+'.html')).write_text(e['explanation_html'])
  records.append({'case':kind,'source_generation':e['provenance']['inputs']['projection_generation'],
    'recommended':e['recommendation'],'eligible':e['generated_trade_eligible'],
    'lineup_impacts':e['lineup_impact'],'sides':{s:{'summary':context[('your_side_summary' if s=='active' else 'their_side_summary')],
     'week8':e['multi_horizon_impact']['sides'][s]['weekly'][8]} for s in ('active','partner')},
    'seconds':durations,'median_seconds':statistics.median(durations),
    'fixture_scope':'Source-compatible disposable twelve-team league; not live Granite or Arkham'})
 finally:f.doCleanups()
 gc.collect()
stat={line.split()[0]:int(line.split()[1]) for line in (read('memory.stat') or '').splitlines()}
report={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),
 'python':platform.python_version(),'observed_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
 'limit':read('memory.max'),'initial_current':initial,'final_current':read('memory.current'),
 'peak':read('memory.peak'),'events':read('memory.events'),'anonymous':stat.get('anon'),'inactive_file':stat.get('inactive_file'),
 'admission_policy':'Unmodified Trade 256 MiB + 128 MiB safety; FOIS independent 768 MiB; per-request gate tested separately',
 'method':'10 warm evaluation samples per controlled fixture, fresh enforced 2 GiB/no swap container; no universal performance claim',
 'records':records}
(out/'report.json').write_text(json.dumps(report,indent=2)); print(json.dumps({k:report[k] for k in ('head','tree','limit','peak','events')}));print([(r['case'],r['median_seconds'],r['recommended']) for r in records])
