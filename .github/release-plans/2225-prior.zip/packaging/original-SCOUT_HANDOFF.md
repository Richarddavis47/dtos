# Build 2225 independent acceptance

Validated candidate (final gates must be verified in attached VALIDATION.json): `6fc4d49bec335dc0cc4e2e24ceaf2dedeb2c39aa`.
Source tree: `e4669e8a4517e29f1d45a332580a52af439adab1`.
Application PR: https://github.com/Richarddavis47/dtos/pull/314
Baseline: build 2224, `11eec0d4fa958c8e68e4e3187dff48d43e067809`.
Actual merged/deployed identity and immutable release attachment hashes belong to the publisher certificate; do not infer deployment from a passing candidate.

## Supported change

Completed evaluations already contain independently optimized weekly pre/post starter and disjoint reserve assignments. The new disclosure verifies these against pinned league/season/week/scoring/generation, hypothetical ownership, exact slot multiplicity, eligibility, published individual contributions and admitted totals. No provider or optimizer runs when opening the disclosure. Unsupported phases are withheld independently. Submitted Sleeper starters are not changed.

Both franchises now expose before/after slots, resolved names/positions, contributions, rounded totals, compatible publication identifiers and recorded availability/reserve limitations. Repeated slots are numbered. Incoming/starter current-week risks appear by the primary decision. Expanded weekly totals retain four decimal places; compact numbers use existing two-decimal formatting. Canonical values, hashes, sorting and thresholds remain unchanged.

The exact-source frozen comparison completed all 180 packages with identical evaluation IDs, protected numerical/verdict digest, funnel and selected packages. Its 123 strategic / 57 counterparty / zero evidence-limited / zero qualified results are a disposable comparison, NOT the earlier live Granite 107/44/29 run. The latter's 44 individual causes remain unknown because the original per-package packet was unavailable. New aggregate cause counts are overlapping recorded requirements with an explicit denominator, separately from contextual availability/reserve/history limitations; they do not prove upstream absence.

Separate baseline/candidate slot-coverage snapshots use identical fixture publications and have identical canonical phase records and verdicts. Complete one-QB: 0 → 40/40 displayed starter assignments; missing required DEF: 0 → 38/40, with two phase gaps explicit and no complete total fabricated; genuine zero DEF: 0 → 40/40; Superflex with its own bonus scoring and no artificial dedicated TE slot: 0 → 40/40. These are assignment rows across two sides × two phases × ten required slots, not 40 new player projections or recovery of the original 44 assessments.

## Smallest safe live check

1. Confirm actual deployed build/commit against the immutable publication certificate.
2. Enter Granite normally. Check selected account/franchise, season/week, scoring and compatible prepared publication/freshness. Do not force source refresh or FOIS rebuild.
3. Inspect current resource admission separately. Prefer an existing supported assessment; if a fresh result is necessary, run ONE bounded normal search only when admission permits. Capacity deferral is not a completed evaluation. Zero qualified offers after completed execution is valid.
4. Expand “Before and after · both optimal lineups” on a supported assessment. Check BOTH franchises, BOTH phases: QB, two RB, two WR, TE, two FLEX, K, DEF. Independently compare each disclosed player with the actual hypothetical pre/post roster, eligible slot and same-publication projection. Verify exact canonical contributions sum to totals; displayed rounded contributions may have a rounding residual.
5. Verify a bench replacement can enter the independently optimized post-trade lineup. Do not assume the incoming asset replaces the outgoing starter directly. Preserve submitted starters separately.
6. Check availability-qualified reserves and primary risks. Missing projections are unknown, genuine zero remains zero. Future-week recorded status is not a recovery forecast. An incompatible phase must not display an invented complete lineup or invalidate another independently supported phase.
7. Confirm the authoritative bilateral verdict remains dominant. A user gain does not qualify a package with a counterparty loss or other blocker. Neutral and Custom evidence remain distinct; exact pick identity/owner remain unchanged.
8. At 320×432, 375×667, 390×844 and desktop, check keyboard focus/Enter, touch, readable slots and warnings, no horizontal overflow. No new request should occur merely from expansion.

Do not change rankings, goals, valuation method/preferences, lineups, offers or production infrastructure. Retained workspace assessments remain NOT REVALIDATED; the new source-detail context is intentionally not added to persistent browser evidence. Explicit reevaluation is required for a fresh slot audit after reload.

## Evidence and limits

The recovery archive contains the final local canonical run, exact-source Trade/league-entry proofs, matched comparison, responsive captures, contrast calculations, focused results and prior failed/incomplete attempts. Original hosted artifacts and their API/file digests are separate release attachments. Verify every SHA256SUMS/manifest entry and the source tree.

Actual 2 GiB controls prove healthy execution, unsafe deferral, explicit recovery, real cancellation/timeout/failure cleanup, one-QB K/DEF evaluation and FOIS lease coordination. Trade 256+128 MiB and FOIS 768 MiB policies are unchanged. Pressure fixtures intentionally approach the raw ceiling; padding/file-cache measurements are retained and must not be subtracted to claim production headroom. Trade is an in-process cooperative worker thread; FOIS child ownership/reaping is tested separately.

Frozen no-padding search comparison: baseline 13.56 seconds / 317,931,520 peak cgroup bytes / 5,178,372 response bytes; candidate 13.48 seconds / 334,331,904 bytes / 11,906,738 response bytes. This is application execution on one frozen fixture, not browser latency, a universal speedup or production-capacity clearance. The response-size increase is a remaining delivery cost.

Owner-authorized connected browser inspection required reauthentication. Live Granite recovery, the original historical availability snapshot and physical iPhone/Safari acceptance remain unverified. Fixture/replay evidence must not be presented as those live results. Obtain the original 180-package packet before attributing the original 44 limited assessments to specific causes.
