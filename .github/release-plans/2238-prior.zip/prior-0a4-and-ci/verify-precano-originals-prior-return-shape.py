from pathlib import Path
import hashlib,json,sys,zipfile
b=Path('/workspace/2238-resident-refresh');sys.path.insert(0,'/workspace/dtos-publisher-2238');from tools.release import publish as p
plan=json.loads(Path('/workspace/dtos-publisher-2238/.github/release-plans/2238.json').read_text());records=json.loads((b/'hosted-final49-interim-records.json').read_text());allmeta={a['name']:a for r in records for a in r['artifacts']};checks={
'actuals-restoration-2g':p.verify_actuals_restoration,'restoration-unused-2g':p.verify_restoration_unused,'resident-refresh-ownership-2g':p.verify_resident_refresh,'trade-resource-2g':p.verify_trade_resource,'league-entry-2g':p.verify_league_entry,'restoration-preflight-2g':p.verify_preflight,'current-season-history-browser':p.verify_current_history,'current-production-coverage-browser':p.verify_current_production,'market-history-coverage-browser':p.verify_market_history,'history-followthrough-browser':p.verify_history_followthrough}
rows=[]
for f in sorted((b/'hosted-originals').glob('*.zip')):
 n=f.stem
 if n=='canonical-release-2g-python314':continue
 a=allmeta[n];assert a['workflow_run']['head_sha']==plan['candidate'] and not a['expired'];assert f.stat().st_size==a['size_in_bytes'] and 'sha256:'+p.digest(f)==a['digest'];p.verify_zip(f)
 if n in checks:assert checks[n](f,plan)['passed']
 if n.startswith('linux-market-lifecycle-'):
  with zipfile.ZipFile(f) as z:r=json.loads(z.read('summary.json'))
  assert r['passed'] and r['completed'] and r['exit_code']==0 and r['memory_max']==2147483648
 rows.append({'name':n,'id':a['id'],'sha256':p.digest(f),'bytes':f.stat().st_size,'source_head':a['workflow_run']['head_sha'],'verified':True})
assert len(rows)==14,'Every required noncanonical original must exist'
(b/'hosted-precanonical-artifacts-verified.json').write_text(json.dumps({'candidate':plan['candidate'],'tree':plan['tree'],'originals':rows,'passed':True},indent=2)+'\n');print('PASS14originals,APIhead/digest/size/CRC/specialized guards')
