# Sleeping-maintenance reference ownership

**Status: final validation in progress. PR #327 is held; no release or deployment is claimed in this record.**

DTOS retained full league dictionaries in two sleeping maintenance paths after those paths no longer needed them. The correction removes those unnecessary references while keeping current publications, active readers, persistent recovery evidence, and every existing memory guard intact. It does not establish live Granite recovery.

Baseline: v1.22.22/build 2237, commit `1e1234fbcf7ca18f3862e5cdeac1451780e51b49`, tree `4051883efb1f225dcd71e07f1998e45c9d96fb39`.

Candidate: v1.22.23/build 2238, commit `0a4b2aba52a3ebd65ec2c110c2377bfb3f9e7662`, tree `ab6d36fe3a543841e670c48f9654f64aeb5f01d3`.

## Confirmed defects

1. `services.league_maintenance.ensure_periodic_refresh` kept a completed refresh task through its next interval. The task's result or exception traceback could retain a superseded complete source graph after a later legitimate publication. Its local reference is now released after terminal handling. Repeated cancellation also drains the existing writer through `shield` before state can be closed or released.
2. `dtos_app.refresh_global_evidence` kept its full `STATE['data']` local during acquisition and the subsequent six-hour sleep, although it needed only scalar season identity. This separately owned task does not have to appear in a runtime's `background_tasks` set. It now drops the dictionary reference immediately after reading the season. Acquisition, cadence, locks, statuses, and selected season remain unchanged.

These are one lifecycle-ownership correction. There is no runtime eviction or catalog-sharing implementation. No context is displaced, so the correction adds no reopening or synchronization cost. A current publication or legitimate older reader still owns its evidence. Failed restoration still retains the last valid current publication.

## Evidence and measured impact

The accepted decoder reconciliation is reused without repeating it. New comparisons vary maintenance ownership only. The native fact/disclosure digest remains `a3ca90c8ad53ef274ffcfee4506fcdd239df9363a54efba67a358c4e47fb6367`.

Resident-task controls used commit `509ad3a98813e549d47e743045828bb285adb7bc`; its entire production refresh function is byte-identical in the final candidate. Three matched full-publication pairs showed approximately 54.7–56.3 MiB less obsolete settled memory. Failure and active-reader controls are retained separately.

Global-only controls run on the final candidate. Three matched normal pairs recover approximately 55.1–56.3 MiB of settled memory; a failed-acquisition pair recovers approximately 55.2 MiB. A real old reader intentionally retains the old source until it releases it. File-backed counters are disclosed separately; the settled difference is anonymous/application memory. Do not add the resident and global figures as if they necessarily describe different graphs.

All matched runs use identical source, payloads, decoder, digest behavior, instrumentation, real admission, and an enforced 2 GiB/no-swap/two-CPU/offline environment. The global fixtures add only `nfl_state.season`, derived from their existing fictional league season. Native facts remain unchanged. Both measured cache restorations and canonical publications are real. Acquisition is mocked identically to inspect scheduler ownership; this is not an ingestion-completion claim.

Absolute operation high-water marks through both publications are about 403 MiB and materially unchanged. They are not isolated cold-restoration bounds. Verification walks and the global protocol's separate A-verification restore occur after the primary peak is captured. GC and allocator trim are identical in both controls and separately disclosed. Logical object release is observed before GC; approximately 55 MiB is a settled figure, not a guarantee of immediate operating-system memory return.

These are source-compatible disposable payloads, not the private Granite cache. Matching serialized size does not prove equal memory demand. Finite cleanup cycles do not establish long-term leak freedom. The full 16× admission allowance remains unchanged.

## Focused and resource acceptance

- Before the resident correction: seven methods expose five failures. After correction, the new and existing maintenance methods pass.
- Before the global correction: four methods expose six failing scenarios. Success, failure, deferral, absent season, incomplete startup, and legitimate old readers pass afterward.
- Final focused scope: 81 passing tests.
- Final local and hosted constrained-container scope: four passing ownership/restoration cases. Actual guarded restoration, native binding, projection restoration, canonical publication, incompatible identity rejection, and active-reader protection are exercised. Unsafe pressure defers; the FOIS standing reservation remains protected; explicit fixture-pressure relief permits a real cold restoration. Three repeated publications per resident case and a real pending writer's repeated-cancellation drain complete with no child workers or scratch state left behind.
- The global case mocks acquisition only; it performs real restoration/publication and checks the real scheduler's source ownership and exit.
- Final local mandatory regression: 4,261 tests and all ten canonical gates passed, in a clean writable Python 3.14.3 checkout under actual 2 GiB/no swap/two CPU/offline controls. All 640 local manifest entries and the full original console checksum were verified. Peak aggregate cgroup memory was 2,002,882,560 bytes, with zero OOM/kill events; the final cleanup gate passed. This full-suite peak includes intentional test pressure and is not a cache-restoration estimate.
- Final Product: 757 passing test executions. The 12 non-canonical hosted jobs and 14 corresponding original archives have passed source, checksum, and specialized guard verification. Hosted canonical completion remains pending at the time this report is drafted.

The first hosted Python 3.12 resource control correctly deferred after logical owner release because insufficient allocator pages returned immediately. The fixture had assumed that release alone would guarantee admission. The final protocol records that state separately, explicitly releases its own remaining pressure, checks actual capacity, and then performs one real recovery restoration. Recovery is not attributed solely to the product change. No reserve, assertion, or production guard is relaxed.

## Production observations and limits

The baseline was confirmed through repository/main, public readiness, and authorized Render deployment metadata. A later bounded retained-log read returned serving-process samples from 01:43 UTC on November 7. They show one pinned warm runtime with no runtime-owned background tasks, two observed processes, approximately 1.53 GB raw cgroup usage, 0.90 GB anonymous memory, and 0.60 GB file-backed memory, with zero OOM counters. Registered source-generation count means source keys, not nine retained full publications.

Those events are historical samples, not a fresh preflight. They establish neither an eviction opportunity nor the byte contribution of the global scheduler's stack local. Other workers' current state, current reservations, Granite's current cache metadata, and current admission remain unestablished. No inactive-file bytes are arbitrarily subtracted.

This session has authorized Render management access but no attached authenticated Shell/SSH executor; the existing browser connector was disconnected. Main Chat's earlier Render-local identity HTTP 200 is supplied evidence, not reproduced. The unchanged external Cloud 401 is not retried or repaired. A fresh existing Render-local preflight, one conditional normal Granite entry, and independent completed-week native Sleeper-to-DTOS score parity remain HELD until that existing live access is available.

No production cache was decoded, no Trade search or forced sync/FOIS rebuild was initiated, and no cache clearing, manual restart, user-setting mutation, credential change, or infrastructure upgrade occurred for diagnosis. Source fixes can make an obsolete graph collectible; if no such unneeded graph exists, there are no corresponding bytes to recover. The 2 GiB plan can still legitimately defer work when current valid data and reservations require more capacity.

## Preserved contracts

The 2 GiB cap, complete 16× physical-cache admission basis, FOIS 768 MiB policy, Trade 256 MiB working reservation plus 128 MiB safety margin, lifecycle leases, and fresh admission rechecks are unchanged. Current warm contexts and active work remain protected. Cache format and persistence, string sharing, native Sleeper actual-results binding, generation/scoring compatibility, exact zeros/negatives/precision, missing/conflicting evidence, exact picks, neutral/Custom valuation, submitted lineups, saved preferences, and retained FOIS provenance are unchanged.

## Earlier attempts and final release boundary

Original failed and incomplete evidence remains separate. Source 509's hosted resource failure and cancelled suites are not passes. Source 108's Product workflow completed successfully; its local and hosted canonical runs were cancelled when the global source-owner defect was found. They do not substitute for final-candidate gates. A global profiler initially retained its own cancelled task reference; the original method/log is retained and the final method drops that harness owner before asserting cleanup.

The first 509 Docker invocation JSON was overwritten before a separate copy was retained. Its source-bound result, console, test/memory events, and trace remain available; no original log is reconstructed. The 108 invocation was preserved. A checkpoint inventory self-inclusion error was caught and corrected without changing source/test bytes; both historical metadata and successful published-byte readback are retained.

Only complete final-source local/canonical/hosted acceptance permits the guarded Actions publisher, normal expected-head merge, immutable publication, and deployment. Final receipts supply authoritative gate counts, manifests, release/merge identity, and production readiness. No disposable result is live Granite acceptance.


## Final source reconciliation (pending mandatory completion)

Candidate49e616bc4d5c4a6d49354eea1f2d015b7a1622b4/tree7ac87bb9ff9f0da6186e50dedd0c93b9bd7bc727 changes only CI allowance relative to0a4. All application modules and the ownership protocol are byte-identical. The123focused methods pass in a clean writable final checkout; the separate original read-only fixture error is preserved. All four final-source2GiB ownership cases, metadata-only preflight and legacy/native actual restoration controls completed and pass publisher guards. No guard or test assertion was weakened.

The earlier0a4local4,261/10gate pass above is a prior exact-source result, not relabeled as49execution. Its hosted canonical attempt failed at4200s while making normal progress:4116completed/4117started,zero failures/errors/skips/OOM. Six gates completed, regression interrupted,three later gates unexecuted. Matched substantial tests were median1.657xlocal. The final CI-only change grants4500s to the same complete validator, with bounded artifact margins; application timeouts/resources are unchanged. The full original failedZIP and all original-readable logs are published and222files read back with checksums at the prior-evidence URL in SCOUT_HANDOFF.md. Final49mandatory suites are separate and still must pass. Final receipts supersede pending status; no production recovery is inferred.
