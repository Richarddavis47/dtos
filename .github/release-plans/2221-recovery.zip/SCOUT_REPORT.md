# DTOS build 2221 safety validation recovery

Candidate v1.22.6/build 2221: 9e540c4ce29d92d106a1a9005e80989ff33330d6. Source tree 67c8ac595bfc7fe9c5d1bb4fc7643ba9ac834d22. Draft PR311 remains held. Production remains v1.22.4/build 2219, commit 118269a2b3c6a6e812422d79818c55d088aff191. K/DEF PR310 remains unchanged and separate.

## Failure diagnosis

The initial Product historical-source failures and Linux preparation/cancellation failures did not execute their intended worker paths: the new conservative guard correctly deferred on unbounded host telemetry. Windows lacked supported bounded-memory telemetry and its original run was interrupted. The archive-warmed test passed but artifact finalization failed ECONNRESET. These are distinct from application lifecycle failures and from the older release-asset HTTP401. The original evidence remains included.

## Corrections

Worker validation now runs in measured, enforced 2 GiB environments. Linux uses raw cgroup memory, including file pages. Windows uses a real aggregate committed-memory Job limit, inherited by children; an unbounded/unknown Job still fails closed. Windows Job telemetry is the only additional application-platform correction in this completion. No Linux admission threshold or intelligence formula changed.

Product worker modules execute in a fresh bounded container, independently of accumulated browser heap. The exact original test-module multiset and assertions remain. Windows retains its two existing POSIX signal skips; Linux executes those controls. No new skip or unrestricted test mode was introduced.

## Real execution and recovery

A repeat on exact final candidate9e540c4 also records parent PID7, worker PID11 and its replacement, and parent-owned resource-tracker PID10. Both owned workers were reaped before return. An actual worker generated two synthetic historical grades. At raw cgroup usage 1,514,283,008 bytes under an actual 2,147,483,648-byte limit, admission deferred before scratch/worker allocation. Previous grades remained RETAINED / NOT REVALIDATED. Ten automatic calls during cooldown caused zero new generation calls. The real liveness route responded in approximately 14.4 ms through the in-process ASGI client. After pressure relief and 61 real seconds, a new real worker completed, scratch was absent and its PID was reaped. The normal Python resource tracker remained parent-owned until container exit; it is not an orphan FOIS worker.

Raw scenario readings: before healthy work 35,368,960 bytes; after completion 78,319,616; pressure 1,514,283,008; after relief 64,315,392; after retry and worker reaping 65,982,464. Declared padding is test workload, not production headroom.

Cancellation, real timeout and graceful interruption controls exercise their original code paths and preserve canonical data. SIGKILL deliberately leaves one scratch directory because Python finally blocks cannot run; the disposable fixture owner removes it after child exit. No production scavenging or hard-kill cleanup guarantee is claimed.

## Reserve and capacity qualification

The reserve is unchanged: 512 MiB working demand plus 256 MiB margin. Production incident worker RSS was 243,073,024 bytes, approximately232 MiB. Large lifecycle fixtures sampled approximately168–170 MiB worker RSS; the tiny recovery worker reported approximately48 MiB. These are observed demands, not a certified maximum for every permitted history. The correction prevents the demonstrated unsafe admission/overlap; it does not eliminate retained parent pressure or prove broad sustained capacity.

Ordinary, archive-warmed and combined-read lifecycle jobs pass. Archive/combined lifetime raw peaks still reach2 GiB during fixture preparation; they have not been suppressed. Their application-observer raw peaks were approximately1.63–1.66 GB. The harness includes roughly914 MB RSS; it is not subtracted to claim production headroom.

## Validation status

Focused Linux and Windows run41345988676 passed35 controls per platform (Windows two pre-existing POSIX skips). Local replay passed29 historical/cancellation/timeout/preparation controls.

Exact-source local canonical:3963 regression tests, zero failures/errors/skips, all ten gates passed in1680.339 seconds. Its551 manifest payload hashes verified. Actual2 GiB memory and swap, two CPUs, network disabled, no OOM events. Lifetime peak1,339,584,512 bytes; final raw current90,275,840 bytes. This is one disposable validation run, not sustained production capacity proof.

Hosted tooling:174 controls on each platform, Windows two existing skips. Product:534+16=550 tests passed. All eleven noncanonical required hosted jobs passed. Hosted canonical41347129005 passed on Python3.14.3:3963 test completions, zero failures/errors/skips, all ten gates in3645.478 seconds. The original68,877,055-byte artifact matches API SHA-256751e766df62130b738201cbb0c38f83228b4e3baf51342ec49b7c34967d3eefc; all553 manifest entries and ZIP integrity verified. Its candidate and source tree exactly match the local run. All12 required hosted jobs passed; the legacy hardcoded publish-2191 job is intentionally skipped, not a release gate. Hosted kernel peak2,012,078,080 bytes, final raw current198,721,536 bytes including150,388,736 inactive-file bytes; OOM counters zero. No source changes occurred after validation. Release evidence publication is the next required step; no merge/deployment has yet occurred.

Production read-only checks:health/live200, health/ready200 on build2219 and the original commit. External liveness samples467.79ms and511.47ms include connection/network overhead. The latter exceeds500ms end to end; neither isolates production handler duration. Controlled pressure liveness was14.4ms through an ASGI test client. Broad production latency compliance is not established. No production user-data, preference, infrastructure or environment change occurred.


## Release authorization blocker

All mandatory application validation passed. Standard GitHub draft creation succeeded, but one standard gh release upload attempt returned HTTP401 Bad credentials from uploads.github.com for release430871975. No unchanged retry or credential workaround was attempted. The asset endpoint's precise credential-binding failure is not established; repository API metadata writes work. The existing authorized GitHub upload credential/session must be restored before evidence publication can finish.

Draft430871975 is unpublished and nonimmutable, intended tagv1.22.6, target9e540c4ce29d92d106a1a9005e80989ff33330d6. Its temporary untagged URL is normal draft presentation; no immutable version tag has been created. Assets remain empty. PR311 remains draft/unmerged, and production remains build2219 at118269a2b3c6a6e812422d79818c55d088aff191. No deployment was attempted. Existing build2219 release draft430134901 and K/DEF PR310 remain untouched.

Scout can inspect the validated source and evidence now; deployed acceptance must wait for authorized publication, merge and deployment. The application correction has not reached production, so the original OOM exposure remains. No source, user preferences, rankings, goals, valuation method or production infrastructure was changed during release preparation.
