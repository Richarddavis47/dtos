Protect FOIS admission with actual raw container headroom before preparation and worker submission, coordinate heavyweight Sleeper/FOIS work, and retire idle workers before source allocations. Safely deferred work retains qualified historical grades and recovers through existing retry controls. No valuation, projection, lineup, grading, saved-preference or Trade-policy changes.

Validated source: 9e540c4ce29d92d106a1a9005e80989ff33330d6; tree 67c8ac595bfc7fe9c5d1bb4fc7643ba9ac834d22. Full local and hosted canonical: 3,963 tests each, all ten gates. Product: 550 tests. All twelve required hosted jobs passed. Original hosted canonical artifact: SHA-256 751e766df62130b738201cbb0c38f83228b4e3baf51342ec49b7c34967d3eefc, 553 verified manifest entries.

The unchanged 768 MiB combined reserve is conservative relative to measured demand; it is not a universal maximum-allocation guarantee. Two lifecycle fixtures retain lifetime 2 GiB peaks. No broad production-capacity clearance is claimed. SIGKILL cannot execute Python cleanup.

K/DEF PR #310 is separate. Production preferences and retained historical grades were not changed during validation.
