import asyncio,gc,json,tempfile,time,os
from pathlib import Path
import psutil
from tests.test_fois_process_execution import fixture,cache_input
from src.core.fois.process_execution import generate_fois_isolated,shutdown_fois_executor
from src.core.fois.repository import FOISRepository
from src.core.league_runtime import LeagueRuntime,RuntimeState
from services.league_maintenance import ensure_fois_refresh
from types import SimpleNamespace
from src.platform.lifecycle import memory_snapshot

def observe():
 s=memory_snapshot();s['observed_at']=time.time();s['parent_pid']=os.getpid();s['processes']=[{'pid':p.pid,'ppid':p.ppid(),'name':p.name(),'status':p.status(),'rss':p.memory_info().rss} for p in [psutil.Process(),*psutil.Process().children(recursive=True)]]
 stat=dict(line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines());s['memory_categories']={k:int(stat[k]) for k in ('anon','file','kernel','shmem','inactive_file','active_file') if k in stat};s['kernel_lifetime_peak_bytes']=int(Path('/sys/fs/cgroup/memory.peak').read_text())
 return s

async def drain(runtime):
 tasks=list(runtime.background_tasks)
 if tasks:await asyncio.gather(*tasks)

async def main():
 assert memory_snapshot()['cgroup_limit_bytes']==2147483648
 report={'candidate':os.environ['DTOS_EXPECTED_HEAD'],'scope':'actual 2GiB synthetic fixture, not broad production capacity proof','phases':{}}
 calls=0
 with tempfile.TemporaryDirectory() as directory:
  root=Path(directory);data=fixture();cache=cache_input(root,data);repo=FOISRepository(root/'fois.sqlite3')
  runtime=LeagueRuntime(league_id=data['league']['league_id'],status=RuntimeState.WARM)
  runtime.state['data']=data;runtime.canonical_context=SimpleNamespace(fois_state='unavailable')
  async def generate(current):
   nonlocal calls
   calls+=1
   scores,_,metrics=await generate_fois_isolated(current,repo,cache_file=cache)
   report.setdefault('executions',[]).append(metrics)
   return scores
  report['phases']['healthy_before']=observe()
  ensure_fois_refresh(runtime,generate);await drain(runtime)
  assert runtime.lifecycle['fois_generation']=='complete'
  assert runtime.lifecycle['fois_records']==2
  assert not list(root.glob('.dtos-fois-compute-*'))
  report['healthy_complete']=True;report['phases']['healthy_after']=observe()
  await shutdown_fois_executor()
  padding=bytearray(1400*1024**2)
  for i in range(0,len(padding),4096):padding[i]=1
  report['phases']['pressure']=observe()
  ensure_fois_refresh(runtime,generate);await drain(runtime)
  assert runtime.lifecycle['fois_generation']=='deferred'
  assert runtime.canonical_context.fois_state=='retained'
  assert not list(root.glob('.dtos-fois-compute-*'))
  for _ in range(10):ensure_fois_refresh(runtime,generate)
  assert calls==2 and not runtime.background_tasks
  report['automatic_retry_count']=0;report['deferred_not_complete']=True
  from fastapi.testclient import TestClient
  import dtos_app
  started=time.perf_counter();r=TestClient(dtos_app.app).get('/health/live')
  report['liveness_ms']=(time.perf_counter()-started)*1000
  assert r.status_code==200 and report['liveness_ms']<500
  del padding;gc.collect()
  report['phases']['relieved']=observe()
  await asyncio.sleep(61)
  ensure_fois_refresh(runtime,generate);await drain(runtime)
  assert runtime.lifecycle['fois_generation']=='complete' and calls==3
  assert runtime.lifecycle['fois_records']==2
  assert not list(root.glob('.dtos-fois-compute-*'))
  worker=report['executions'][-1]['worker_pid']
  await shutdown_fois_executor();assert not psutil.pid_exists(worker)
  report['real_retry_complete']=True;report['worker_reaped']=True
  report['phases']['recovered']=observe()
 print(json.dumps(report))

if __name__=='__main__':asyncio.run(main())
