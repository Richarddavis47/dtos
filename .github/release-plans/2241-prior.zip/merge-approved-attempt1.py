"""Normal expected-head PR merge only after native preparation and exact checks."""
from pathlib import Path
import json, subprocess
from tools.release import publish
b=Path('/workspace/2241-trade-partner-history')
plan=json.loads(Path('/workspace/dtos-publisher-2241/.github/release-plans/2241.json').read_text())
source=json.loads((b/'source.json').read_text())
publisher=json.loads((b/'publisher-source.json').read_text())['publisher']
prepared=json.loads((b/'prepared-publication.json').read_text())
verified=json.loads((b/'prepared-attachment-verification.json').read_text())
assert prepared['candidate']==verified['candidate']==source['candidate'] and prepared['tree']==verified['tree']==source['tree']
assert prepared['publisher']==verified['publisher']==publisher and prepared['draft'] and not prepared['immutable']
assert verified['native_all_attachment_bytes_read_back'] and verified['cloud_api_digests_match_certificate']
assert len(verified['attachments'])==23
repo='repos/'+plan['repository']
def api(path):return json.loads(subprocess.check_output(['gh','api',repo+'/'+path],text=True))
run=api('actions/runs/'+str(json.loads((b/'preparation-run.json').read_text())['id']))
assert run['status']=='completed' and run['conclusion']=='success' and run['head_sha']==publisher
assert api('git/ref/heads/main')['object']['sha']==source['baseline']
tag_lookup=subprocess.run(['gh','api',repo+'/git/ref/tags/v1.22.26'],capture_output=True,text=True)
assert tag_lookup.returncode!=0 and 'HTTP 404' in tag_lookup.stderr, 'Target immutable version is no longer unused; hold before any merge/publication.'
pr=api('pulls/330');assert not pr['merged'] and pr['state']=='open' and pr['head']['sha']==source['candidate'] and pr['base']['sha']==source['baseline']
assert api('git/commits/'+source['candidate'])['tree']['sha']==source['tree']
records,_=publish.verify_runs(plan);assert len(records)==13
if pr['draft']:
 query='mutation($id:ID!){markPullRequestReadyForReview(input:{pullRequestId:$id}){pullRequest{number isDraft}}}'
 result=json.loads(subprocess.check_output(['gh','api','graphql','-f','query='+query,'-f','id='+pr['node_id']],text=True))
 assert not result.get('errors') and result['data']['markPullRequestReadyForReview']['pullRequest']=={'number':330,'isDraft':False}
body={'sha':source['candidate'],'merge_method':'squash',
 'commit_title':'feat: show source-qualified completed franchise trade observations (#330)',
 'commit_message':'Add bounded display-only completed-trade and first-round transfer facts to existing Franchise History. Preserve exact pick direction, franchise continuity, source clocks, unknown coverage, supporting trades and contextual Back. No manager-intent inference or new Trade/FOIS/valuation input.
\nValidated application tree: '+source['tree']+'
\n4,308 tests and all ten canonical gates passed locally and hosted; all thirteen hosted jobs and 821 Product executions passed. Frozen native Actions preparation verified all 23 attachments before normal expected-head merge. Source replay and disposable controls remain separate from unverified authenticated live acceptance. Original failures/preliminary logs remain distinct. No provider backfill, heavy production work or saved-data mutation.'}

(b/'merge-input.json').write_text(json.dumps(body,indent=2)+'\n')
result=json.loads(subprocess.check_output(['gh','api',repo+'/pulls/330/merge','--method','PUT','--input',str(b/'merge-input.json')],text=True))
assert result['merged'] is True
sha=result['sha'];assert api('git/ref/heads/main')['object']['sha']==sha
assert api('git/commits/'+sha)['tree']['sha']==source['tree']
report=dict(merge_commit=sha,candidate=source['candidate'],tree=source['tree'],publisher=publisher,pr=330,normal_expected_head_squash=True,validated_tree_unchanged=True)
(b/'merged-source.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
