import os,sys,subprocess,json
from pathlib import Path
base=Path('/tmp/market-needs-fixture');base.mkdir(exist_ok=True)
for key,name in {'CACHE':'cache.json','PROJECTION_DB':'projections.sqlite3','METADATA_DB':'metadata.sqlite3','INTELLIGENCE_CHECKPOINT':'intelligence.sqlite3','FOIS_DB':'fois.sqlite3','HISTORY_DB':'history.sqlite3','ACCOUNT_DB':'accounts.sqlite3'}.items():os.environ['DTOS_'+key+'_FILE']=str(base/name)
os.environ.update(DTOS_DURABLE_HISTORY_REQUIRED='0',SLEEPER_BASE_URL='http://127.0.0.1:9/v1',SLEEPER_LEAGUE_ID='1804000000000000000',DTOS_FIXTURE_ROOT=str(base),DTOS_SLEEPER_SEASON_CACHE_ROOT=str(base/'season-cache'),DTOS_HISTORY_STORAGE_ROOT=str(base))
cg=Path('/sys/fs/cgroup');assert int((cg/'memory.max').read_text())==2147483648
r=subprocess.run([sys.executable,'-m','unittest','-v','tests.test_market_roster_relevance'])
Path('/output/result.json').write_text(json.dumps(dict(exit_code=r.returncode,passed=r.returncode==0,limit=int((cg/'memory.max').read_text()),peak=int((cg/'memory.peak').read_text()),events=dict(line.split() for line in (cg/'memory.events').read_text().splitlines()),scope='Development source; original failures retained, not exact-source release acceptance'),indent=2)+'\n');raise SystemExit(r.returncode)
