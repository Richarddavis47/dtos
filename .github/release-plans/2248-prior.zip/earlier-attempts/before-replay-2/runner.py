import os,sys,subprocess,json
from pathlib import Path
base=Path('/tmp/market-needs-fixture');base.mkdir(exist_ok=True)
for key,name in {'CACHE':'cache.json','PROJECTION_DB':'projections.sqlite3','METADATA_DB':'metadata.sqlite3','INTELLIGENCE_CHECKPOINT':'intelligence.sqlite3','FOIS_DB':'fois.sqlite3','HISTORY_DB':'history.sqlite3','ACCOUNT_DB':'accounts.sqlite3'}.items():os.environ['DTOS_'+key+'_FILE']=str(base/name)
os.environ.update(DTOS_DURABLE_HISTORY_REQUIRED='0',SLEEPER_BASE_URL='http://127.0.0.1:9/v1',SLEEPER_LEAGUE_ID='1804000000000000000',DTOS_FIXTURE_ROOT=str(base),DTOS_SLEEPER_SEASON_CACHE_ROOT=str(base/'season-cache'),DTOS_HISTORY_STORAGE_ROOT=str(base))
cg=Path('/sys/fs/cgroup');assert int((cg/'memory.max').read_text())==2147483648
import runpy,unittest
sys.path.insert(0,"/app")
namespace=runpy.run_path('/new-fixture/test_market_roster_relevance.py')
rows=[]
for sf in (False,True):
    case=unittest.TestCase()
    try:
        f=namespace['MarketNeedFixture'](case,superflex=sf,depth=sf)
        response=f.client.get('/market',params={'q':f.player_id,'selected':f.asset_id,'front_office':1})
        team=f.client.get('/teams/1')
        assert response.status_code==team.status_code==200
        assert 'id="market-roster-movement"' not in response.text
        assert 'Explore RB trades' in team.text
        assert '+150.00 Market points' in response.text
        rows.append(dict(shape='superflex-depth' if sf else 'oneqb-starter',asset=f.asset_id,canonical_movement=150,prepared_need_in_my_team=True,market_personal_join=False,existing_generic_target_link=True))
    finally:case.doCleanups()
record=dict(baseline=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),passed=True,observations=rows,scope='New source-compatible disposable fixture replayed against unchanged build2247 baseline; not production owner data or historical reconstruction')
Path('/output/result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
