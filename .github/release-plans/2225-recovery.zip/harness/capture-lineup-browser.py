"""Extra visual/contrast evidence on the frozen candidate, disposable HTTP only."""
import json
import os
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path.cwd()))
os.environ['DTOS_LINEUP_DETAIL_EVIDENCE'] = '/evidence/browser-final'
from playwright.sync_api import Page
from tests.test_trade_lineup_detail_browser import TradeLineupDetailBrowserTests

original = Page.screenshot
colors = []
def capture(page, *args, **kwargs):
    observed = page.evaluate('''() => [...document.querySelectorAll('.tw-lineup-table td, .tw-lineup-table td small, .tw-lineup-source, .tw-lineup-details > summary')].map(e => {
      const s=getComputedStyle(e); let parent=e, bg='';
      while(parent){const p=getComputedStyle(parent); if(p.backgroundColor!=='rgba(0, 0, 0, 0)'){bg=p.backgroundColor;break;} parent=parent.parentElement;}
      return {kind:e.tagName, foreground:s.color, background:bg, size:s.fontSize};
    })''')
    colors.append({'viewport': page.viewport_size, 'styles': observed})
    root = Path('/evidence/browser-final')
    root.mkdir(parents=True, exist_ok=True)
    weeks = page.locator('.tw-lineup-details .tw-lineup-week')
    for i in [0, 3]:
        if i < weeks.count():
            weeks.nth(i).screenshot(path=str(root / f'slot-audit-{page.viewport_size["width"]}-{i}.png'))
    weeks.first.locator('h4').evaluate('(e)=>e.scrollIntoView({block:"start"})')
    return original(page, *args, **kwargs)
Page.screenshot = capture
case = TradeLineupDetailBrowserTests('test_one_qb_slot_audit_at_four_sizes_without_extra_requests')
result = case.defaultTestResult()
try:
    case.run(result)
finally:
    Page.screenshot = original
assert result.wasSuccessful(), repr(result.failures + result.errors)
root = Path('/evidence/browser-final')
(root/'contrast-styles.json').write_text(json.dumps(colors,indent=2))
(root/'source.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),
    'scope':'Disposable authenticated source-compatible fixture, Chromium keyboard and CDP touch emulation, not live Granite or physical Safari.'},indent=2))
print('Four-view fixture evidence, keyboard/touch/reload and styles captured.')
