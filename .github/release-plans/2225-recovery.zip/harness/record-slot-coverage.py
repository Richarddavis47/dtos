"""Source-compatible coverage counts, never the private historical Granite run."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

sys.path.insert(0,str(Path.cwd()))
from services.trade_intelligence import evaluate_trade_request
from tests.test_multileague_projection_compatibility import MultiLeagueProjectionTests

label=sys.argv[1]
f=MultiLeagueProjectionTests();f.setUp()
f.data['market_data']={'providers':{'FantasyCalc':{pid:{'value':3000,'confidence':90}
    for pid,p in f.data['players'].items() if p['position'] not in {'K','DEF'}}}}
rows=[]
def record(name):
    e=evaluate_trade_request(f.data,{'active_roster_id':1,'partner_roster_id':2,
       'assets_sent':['1-10'],'assets_received':['2-0'],'workflow':'create','strategy':'RETOOL'},
       projection_reader=f.service)['evaluation']
    phases=[]
    for side in ('active','partner'):
        for phase in ('pre','post'):
            r=e['multi_horizon_impact']['sides'][side]['weekly'][8][phase]
            o=r['optimal'];entries=o['entries']
            phases.append(dict(side=side,phase=phase,available=r['available'],
                total=o['projected_points'],known_subtotal=o['known_starters_subtotal'],
                entries=entries,unsupported_slots=o['unsupported_slots']))
    html=e['explanation_html']
    tables=re.findall(r'<table class="tw-lineup-table">(.*?)</table>',html,re.S)
    displayed=sum(t.count('<th scope="row">') for t in tables if 'analytical optimal starters</caption>' in t)
    rows.append(dict(case=name,league=f.data['league'],source=f.service.snapshot(),
        expected_starting_assignments=40,canonical_known_assignments=sum(len(p['entries']) for p in phases),
        displayed_starting_assignments=displayed,phases=phases,verdict=e['recommendation'],
        html_sha256=hashlib.sha256(html.encode()).hexdigest()))
try:
    f.publish();record('complete_one_qb')
    f.feed=[r for r in f.feed if r['player_id']!='1-9'];f.publish();record('missing_def')
    f.feed.append({'player_id':'1-9','season':2026,'week':8,'player':{'position':'DEF'},'stats':{'sack':0,'int':0}})
    f.publish();record('genuine_zero_def')
    f.test_superflex_without_dedicated_te_preserves_legal_scoring();record('superflex_own_bonus_scoring')
finally:f.doCleanups()
report=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),cases=rows,
    scope='Disposable compatible 12-team publication and two-franchise hypothetical evaluation; not live Granite or its original 44 limited assessments.')
Path('/evidence/slot-coverage-'+label+'.json').write_text(json.dumps(report,indent=2,default=str))
print(json.dumps([dict(case=r['case'],expected=r['expected_starting_assignments'],canonical=r['canonical_known_assignments'],displayed=r['displayed_starting_assignments']) for r in rows]))
