"""Pinned-publication baseline/candidate comparison; actual 2 GiB, no ballast."""
import asyncio
import gc
import hashlib
import json
import logging
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))

os.environ['DTOS_PROJECTION_DB_FILE'] = '/tmp/comparison-projections.sqlite3'
os.environ['DTOS_CACHE_FILE'] = '/tmp/comparison-cache.json'
logging.disable(logging.WARNING)
from services import trade_intelligence as trade
from src.core.projection_intelligence.service import ProjectionService
from src.core.data_platform import data_platform
from src.core.data_platform.storage import SnapshotWarehouse
from src.platform import trade_execution as execution
from src.platform.lifecycle import lifecycle_coordinator

label = sys.argv[1]
folder = Path('/evidence/comparison')
data_path = folder / 'fixture/data.json'
data = json.loads(data_path.read_text())
for team in data['team_strength']['teams'].values():
    team['weekly'] = {int(k): v for k, v in team['weekly'].items()}
reader = ProjectionService(folder / 'fixture/projections.sqlite3')
assert execution.observe_memory()['cgroup_limit_bytes'] == 2 * 1024**3
samples, stop = [], threading.Event()
def sample():
    m = execution.observe_memory()
    return {'at': time.monotonic(), 'current': m['cgroup_current_bytes'],
            'anon': m.get('file_accounting', {}).get('anon'),
            'file': m.get('file_accounting', {}).get('file'),
            'rss': m['rss_bytes'], 'events': m['cgroup_memory_events']}
def watch():
    while not stop.wait(.05): samples.append(sample())
thread = threading.Thread(target=watch)
thread.start()
evaluations, seconds, digest = 0, 0, hashlib.sha256()
identity_digest = hashlib.sha256()
evaluation = trade.evaluate_trade_request
def assess(*args, **kwargs):
    global evaluations, seconds
    started = time.monotonic()
    report = evaluation(*args, **kwargs)
    seconds += time.monotonic() - started
    e = report['evaluation']
    identity_digest.update(e['provenance']['evaluation_id'].encode())
    # Entire canonical numeric impact, all prices, decisions and reason codes.
    # Presentation/context additions and evaluation-ID hashes are excluded.
    protected = {k: e.get(k) for k in ('legal', 'legality', 'recommendation',
        'recommendation_availability', 'generated_trade_eligible', 'reason_codes',
        'values', 'market_evidence', 'multi_horizon_impact', 'recommendation_trace')}
    digest.update(json.dumps(protected, sort_keys=True, default=str).encode())
    evaluations += 1
    return report
before = sample()
before_data = hashlib.sha256(json.dumps(data, sort_keys=True, default=str).encode()).hexdigest()
try:
    with patch('services.trade_intelligence._trade_projection_service', return_value=reader), \
         patch.object(data_platform, 'warehouse', SnapshotWarehouse()), \
         patch.object(trade, 'evaluate_trade_request', side_effect=assess):
        started = time.monotonic()
        result = asyncio.run(execution.run_trade_operation(lambda: trade.generate_trade_workflow(data,
            {'active_roster_id': 1, 'workflow': 'recommended', 'strategy': 'REBUILD'})))
        elapsed = time.monotonic() - started
    assert result['search_evidence']['full_evaluations'] == evaluations == 180
    assert lifecycle_coordinator.trade_search_available()
    after = sample()
    encoded = json.dumps(result, default=str)
    selected = {name: [r['proposal'] for r in result.get(name) or []]
                for name in ('results', 'near_misses', 'exploratory_results')}
    report = {'label': label, 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
              'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
              'working_tree_clean': not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip(),
              'fixture_sha256': hashlib.sha256(data_path.read_bytes()).hexdigest(),
              'projection_generation': reader.snapshot()['projection_snapshot_id'],
              'seconds': elapsed, 'evaluation_seconds': seconds, 'full_evaluations': evaluations,
              'protected_digest': digest.hexdigest(), 'identity_digest': identity_digest.hexdigest(), 'selected_packages': selected,
              'qualified': result['count'], 'result_state': result['result_state'],
              'funnel': {k: result['search_evidence'].get(k) for k in ('evaluated', 'strategically_rejected',
                  'counterparty_limited', 'missing_evidence', 'hard_invalid', 'eligible')},
              'response_bytes': len(encoded), 'before': before, 'after': after}
    del result, encoded
    gc.collect()
    time.sleep(2)
    report['idle'] = sample()
    report['trade_lease_available'] = lifecycle_coordinator.trade_search_available()
    report['source_data_unchanged'] = before_data == hashlib.sha256(json.dumps(data, sort_keys=True, default=str).encode()).hexdigest()
    assert report['source_data_unchanged']
finally:
    stop.set()
    thread.join()
report['samples'] = samples
report['peak_current'] = max([before['current'], after['current'], *[s['current'] for s in samples]])
report['peak_rss'] = max([before['rss'], after['rss'], *[s['rss'] for s in samples]])
report['scope'] = 'Same frozen disposable publication, actual 2 GiB/two CPU/network none; no production search, no harness memory padding. Timing is fixture-specific.'
(folder / (label + '.json')).write_text(json.dumps(report, indent=2, default=str))
print(json.dumps({k: v for k, v in report.items() if k not in ('samples', 'selected_packages')}, default=str))
