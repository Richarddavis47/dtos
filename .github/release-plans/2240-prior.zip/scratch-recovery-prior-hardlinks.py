from pathlib import Path
import hashlib,json,os,shutil,tarfile
b=Path('/workspace/2240-trade-time-market')
roots=[Path('/workspace')/name/'source' for name in ['2221-local','2222-local','2223-final','2223-final-attempt1','2223-local','2223-resumed-final','2224-local','2224-local-attempt2','2225-local']]
assert all(p.is_dir() for p in roots)
out=Path('/workspace/prior-validator-source-originals.tar.gz')
assert not out.exists()
rows=[];skipped=[]
for root in roots:
 for p in sorted(root.rglob('*')):
  if p.is_symlink():rows.append(dict(path=str(p),type='symlink',target=os.readlink(p)))
  elif p.is_file():
   try:
    with p.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    rows.append(dict(path=str(p),type='file',bytes=p.stat().st_size,sha256=sha))
   except PermissionError:skipped.append(str(p))
with tarfile.open(out,'w:gz',compresslevel=6) as t:
 for r in rows:
  t.add(r['path'],arcname=str(Path(r['path']).relative_to('/workspace')),recursive=False)
with tarfile.open(out,'r:gz') as t:
 members={m.name:m for m in t.getmembers()}
 for r in rows:
  item=members[str(Path(r['path']).relative_to('/workspace'))]
  if r['type']=='symlink':assert item.issym() and item.linkname==r['target']
  else:
   assert item.isfile() and item.size==r['bytes'];assert hashlib.file_digest(t.extractfile(item),'sha256').hexdigest()==r['sha256']
report=dict(archive=str(out),archive_bytes=out.stat().st_size,archive_sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),original_files=rows,unreadable_preserved_unchanged=skipped,scope='Lossless old completed/interrupted standalone validation source snapshots, every original byte verified before removal. No current task source, log, Git worktree, immutable publication or production data removed.')
(b/'scratch-recovery.json').write_text(json.dumps(report,indent=2)+'\n')
errors=[]
for r in rows:
 path=Path(r['path'])
 try:path.unlink()
 except OSError as e:errors.append(dict(path=str(path),error=type(e).__name__))
report['cleanup_errors']=errors;report['free_bytes_after']=shutil.disk_usage('/workspace').free
(b/'scratch-recovery.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='original_files'})
