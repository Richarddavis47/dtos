import sys,importlib.util,unittest,json,subprocess
from pathlib import Path
sys.path.insert(0,"/app")
spec=importlib.util.spec_from_file_location("trade_time_baseline_probe","/evidence/baseline-test-module.py");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
names=["test_newer_incompatible_does_not_hide_older_compatible_quote","test_newer_foreign_scope_does_not_hide_compatible_quote"]
suite=unittest.TestSuite(m.TradeTimeMarketEvidenceTests(name) for name in names)
r=unittest.TextTestRunner(verbosity=2).run(suite)
Path("/evidence/baseline-reproduction.json").write_text(json.dumps({"head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"tree":subprocess.check_output(["git","rev-parse","HEAD^{tree}"],text=True).strip(),"tests":r.testsRun,"failures":len(r.failures),"errors":len(r.errors),"scope":"Expected failing-before fixture controls on unchanged production source; no live quotes"},indent=2)+"\n")
raise SystemExit(not r.wasSuccessful())
