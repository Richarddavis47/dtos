"""Run once inside the existing authenticated Render Shell after deployment.
No application imports, new coordinator, token output or filesystem payload reads.
"""
import json
import os
import sys
import httpx

port = os.environ.get("PORT", "10000")
if not port.isascii() or not port.isdigit() or not 1 <= int(port) <= 65535:
    sys.exit("Unknown local application port; stop without sending the credential.")
token = os.environ.get("DTOS_INSPECTION_AUTH_TOKEN")
if not token:
    sys.exit("Existing inspection credential is unavailable in this Shell; stop.")
url = "http://127.0.0.1:" + port + "/api/inspect/operations/restoration-preflight"
try:
    with httpx.Client(timeout=8.0, follow_redirects=False, trust_env=False) as client:
        response = client.get(url, params={"league_id": "1314695233040052224"},
                              headers={"X-DTOS-Inspection-Auth": token})
    print("HTTP", response.status_code)
    print("Cache-Control", response.headers.get("cache-control", "unknown"))
    if response.status_code != 200:
        sys.exit("Stop: retain status only; do not retry or initiate league entry.")
    if len(response.content) > 256 * 1024:
        sys.exit("Unexpected response size; stop.")
    report = response.json()
except (httpx.HTTPError, ValueError):
    sys.exit("Inspection transport or JSON failure; stop without printing request details.")
allowed = ("schema_version", "observation_started_at", "observation_completed_at",
           "league_id", "advisory_only", "non_atomic", "recheck_required", "assessment_scope",
           "process", "deployment", "runtime", "cache", "lifecycle", "memory", "capacity",
           "unknown_fields", "verdict", "reason")
print(json.dumps({key: report.get(key) for key in allowed}, indent=2))
