# DTOS v1.22.11 / build 2226 — bounded restoration preflight

Validated candidate: 62c6be6790d9b48ca8af06a4024ca4734369f64b
Validated source tree: d77a2ebd8d97400af9da4dc5947e647c5aee60f7
Production baseline: 150339f3d02e40ef161a8eb5d870e9b7c38f5874 / v1.22.10 build2225.
Application PR: https://github.com/Richarddavis47/dtos/pull/315

## Scope and claims

This adds one existing-token-authorized, exact-Granite-scoped, metadata-only GET operation:
`/api/inspect/operations/restoration-preflight?league_id=1314695233040052224`.
The ID selects an explicitly authorized server-owned scope; knowledge of the ID or a hash cannot authorize the request. Existing token semantics remain unchanged. No account cookie/Bearer/query credential is accepted.

The response is advisory and non-atomic. It grants no reservation. It exposes observation times, deployment/PID, serving-process lifecycle flags, shared-container memory, metadata-only file size/age, actual reserve components and would-admit/defer/unknown reasons. It cannot certify payload readability, source/scoring compatibility, idleness of other processes, an earlier rejection cause, or successful restoration. Normal entry must recheck all actual admission and compatibility conditions.

Cache working remains max(128MiB,16×file bytes), cache safety128MiB, effective capmin(cgroup limit,2GiB). With active FOIS, its512MiBworking and max(256MiBFOISsafety,128MiBcache safety) remain protected. No file-cache credit is subtracted. No admission or analytical policy changed.

Linux metadata-only handles reject symlinks/nonregular files and detect observed replacement or mutation without retries. Unsupported safe-handle platforms return unknown. Before/after metadata does not exclude every transient ABA race. Existing query, time, response and per-worker diagnostic-lock budgets remain.

## Final validation

- Local Python 3.14.3: **4,062 tests and all ten gates passed**, with no failures, errors or skips. Process cleanup passed. The run used an enforced 2 GiB limit, no swap, two CPUs and no network. Peak cgroup usage was 1,993,838,592 bytes; OOM events were zero. All 559 manifest payloads matched their checksums.
- Hosted Python 3.14.3: **4,062 tests and all ten gates passed**. All 563 original manifest payloads matched their checksums. Artifact 13286432138 has SHA-256 `bc7de52c1085e129229eeaacdd98279b6db73d6dc329838f5da1c50c923172f4`. The enforced limit was 2 GiB; peak usage was 2,085,498,880 bytes and OOM events were zero.
- **All twelve required hosted jobs passed**: canonical run 41747370686, Product run 41747370691, tooling run 41747370695 and Linux lifecycle run 41747370700. Product passed 595 tests; public Welcome/security passed 404.
- **80 focused tests passed** in an enforced 2 GiB container. Both local and hosted five-case preflight controls passed. Their peak usages, 1,784,053,760 and 1,784,168,448 bytes, include deliberate bounded padding; they do not measure real Granite restoration demand. Prohibited-operation counts were zero, scratch state was removed and no child processes remained.
- Existing hosted Trade and league-entry resource controls passed, including real disposable Trade execution, deferral, recovery, cancellation, one-QB/K/DEF evaluation and FOIS worker lifecycle. These are fixture results, not live Granite acceptance.
- The publisher passed 40 unit tests, Ruff, compilation and whitespace checks. Publisher work did not require another complete application regression.
- Browser evidence covers 320×432, 375×667, 390×844 and 1280×900, with keyboard, touch and overflow checks. Physical iPhone/Safari was not tested.

The 80 focused tests and five-case constrained acceptance are disposable evidence. The five cases prove healthy advisory admission, capacity deferral, pressure recovery, protection while FOIS is marked active, and removal of its reservation after release at unchanged padding. They do not execute a real FOIS rebuild or profile the real Granite cache. A sparse invalid JSON metadata fixture intentionally proves no cache decoding. Guarded expensive-operation call counts are allzero; no scratch or child process remains.

Prior host-capacity failures, the hosted setup-python cache teardown failure after16passingtests, the intentionally interrupted earlier full runs, and corrected publisher fixture attempts remain separately attached. Deferral is not counted as completion of historical or Trade work. Existing canonical/hosted tests separately retain real worker completion/cancellation/timeout and Trade/league-entry controls.

## One bounded Render-local verification

Codex lacks Render Shell access in this session. Main Chat supplied the existing-token identityHTTP200 observation; Codex has not reproduced it. Do not repeat that credential test or repair the separate external Cloud401binding.

After confirming the deployed merge SHA in the published release, use the existing authenticated Render Shell for service srv-d9ctp8navr4c73agtnrg. Run the script below once. The configured start command uses PORT; service metadata identified10000. It sends the token only in the established header to the running local HTTP application, never imports the app or creates a coordinator. Do not log request headers, tokens or environments. Stop after a non200response; no repeated probing.

```python
"""Run once inside the existing authenticated Render Shell after deployment.
No application imports, new coordinator, token output or filesystem payload reads.
"""
import json
import os
import sys
import httpx

port = os.environ.get("PORT", "10000")
if not port.isascii() or not port.isdigit() or not 1 <= int(port) <= 65535:
    sys.exit("Unknown local application port; stop without sending the credential.")
token = os.environ.get("DTOS_INSPECTION_AUTH_TOKEN")
if not token:
    sys.exit("Existing inspection credential is unavailable in this Shell; stop.")
url = "http://127.0.0.1:" + port + "/api/inspect/operations/restoration-preflight"
try:
    with httpx.Client(timeout=8.0, follow_redirects=False, trust_env=False) as client:
        response = client.get(url, params={"league_id": "1314695233040052224"},
                              headers={"X-DTOS-Inspection-Auth": token})
    print("HTTP", response.status_code)
    print("Cache-Control", response.headers.get("cache-control", "unknown"))
    if response.status_code != 200:
        sys.exit("Stop: retain status only; do not retry or initiate league entry.")
    if len(response.content) > 256 * 1024:
        sys.exit("Unexpected response size; stop.")
    report = response.json()
except (httpx.HTTPError, ValueError):
    sys.exit("Inspection transport or JSON failure; stop without printing request details.")
allowed = ("schema_version", "observation_started_at", "observation_completed_at",
           "league_id", "advisory_only", "non_atomic", "recheck_required", "assessment_scope",
           "process", "deployment", "runtime", "cache", "lifecycle", "memory", "capacity",
           "unknown_fields", "verdict", "reason")
print(json.dumps({key: report.get(key) for key in allowed}, indent=2))
```

Check version/build/commit against the immutable release and serving PID against the response's declared scope. Confirm advisory_only/non_atomic/recheck_required true, exact league scope, private/no-store, cache content_compatibility not_evaluated, and specific verdict/reason. Preserve timestamped metadata privately. Unknown/deferred is a legitimate diagnostic result and does not authorize entry.

## Independent acceptance boundary

Scout should first verify immutable tag→merged commit→validated tree, required jobs, original canonical manifest and attachment checksums, then review the one new Render-local metadata snapshot. Do not initiate Granite entry, sync, FOIS work or Trade discovery in this task. No production rankings, preferences, valuation method, goal, submitted lineup or Trade package was changed by testing.

Shipping this diagnostic does not establish Granite recovery or the cause of the earlier503. The original restoration study remains PARTIAL; a similarly sized fixture does not establish real payload allocation demand, and cleanup observations do not establish long-term leak freedom.
