"""Run the unchanged source-defined canonical harness in the verified runtime."""
import json,os,re,subprocess
from pathlib import Path
root=Path('/workspace/2226-release');source=Path('/workspace/dtos')
cache=Path('/workspace/2223-focused314/runtime314-layer-cache-id.txt').read_text().strip();assert re.fullmatch('[a-f0-9]{64}',cache)
runtime='/var/lib/docker/vfs/dir/'+cache
im=json.loads(subprocess.check_output(['docker','image','inspect','dtos-canonical314-flat:2223'],text=True))[0]
assert im['Id']=='sha256:2c9de92bf8e05a79587f6edba94052cf614c984a5cb81a62613871388cd6533e'
assert not any(any(k in v.split('=',1)[0].upper() for k in ('TOKEN','SECRET','PASSWORD','PROXY')) for v in im['Config']['Env'])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert head=='62c6be6790d9b48ca8af06a4024ca4734369f64b'
args=['docker','run','--name','dtos-2226-local-canonical','--rm','--init','--memory=2g','--memory-swap=2g','--cpus=2','--network=none']
for name in ['usr','bin','lib','lib64','etc','opt','var','root','run']:
 args+=['--mount',f'type=bind,src={runtime}/{name},dst=/{name},readonly']
for item in im['Config']['Env']:args+=['--env',item]
args+=['--env','NODE_OPTIONS=--max-old-space-size=256','--env','DTOS_EXPECTED_HEAD='+head,'--volume',str(source)+':/app','--volume',str(root/'local-canonical')+':/output','--volume',str(root/'fixture')+':/fixture','--workdir','/app','dtos-canonical-runtime-mounts:2223','/usr/local/bin/python','/output/runner.py']
(root/'local-invocation.json').write_text(json.dumps({'head':head,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip(),'runtime_image':im['Id'],'command':args,'runner':'Extracted byte-for-byte from candidate canonical workflow; all gates,2GiB/noSwap/twoCPU/networknone and8GiBpreflight unchanged.'},indent=2)+'\n')
raise SystemExit(subprocess.run(args).returncode)
