from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from check_records import validate


def read(folder, label):
    return json.loads((ROOT / folder / ('slot-coverage-' + label + '.json')).read_text())


class MetadataIntegrityTests(unittest.TestCase):
    def test_original_defect_is_reproduced_not_erased(self):
        bad = 0
        corrections = json.loads((ROOT / 'CORRECTIONS.json').read_text())
        for label, mapping in zip(('baseline', 'candidate'), corrections['records']):
            original = ROOT / 'original-records' / ('slot-coverage-' + label + '.json')
            self.assertEqual(hashlib.sha256(original.read_bytes()).hexdigest(), mapping['original_member_sha256'])
            for i, row in enumerate(read('original-records', label)['cases']):
                if i < 3:
                    with self.assertRaisesRegex(AssertionError, 'scoring_profile_mismatch'):
                        validate(row)
                    bad += 1
                else:
                    self.assertTrue(validate(row))
        self.assertEqual(bad, 6)

    def test_corrected_originals_change_only_three_metadata_paths_per_case(self):
        for label in ('baseline', 'candidate'):
            old = read('original-records', label)
            fixed = read('corrected-original-records', label)
            for i, row in enumerate(fixed['cases']):
                self.assertTrue(validate(row))
                if i < 3:
                    self.assertIn('TE', row['league']['roster_positions'])
                    self.assertIn('K', row['league']['roster_positions'])
                    self.assertIn('DEF', row['league']['roster_positions'])
                    for parent, key in (('league', 'roster_positions'), ('league', 'scoring_settings'), ('source', 'scoring_settings')):
                        old['cases'][i][parent][key] = None
                        fixed['cases'][i][parent][key] = None
            self.assertEqual(old, fixed)

    def test_new_replays_preserve_pinned_source_values_and_admission(self):
        for label in ('baseline', 'candidate'):
            original = read('original-records', label)
            replay = read('new-replays', label)
            self.assertEqual((original['head'], original['tree']), (replay['head'], replay['tree']))
            for a, b in zip(original['cases'], replay['cases']):
                self.assertTrue(validate(b))
                for key in ('case', 'phases', 'verdict', 'canonical_known_assignments', 'displayed_starting_assignments'):
                    self.assertEqual(a[key], b[key])
                for key in ('scoring_profile_id', 'projection_snapshot_id', 'horizon_generation', 'sleeper_evidence_snapshot_id'):
                    self.assertEqual(a['source'][key], b['source'][key])
                # A newly generated fixture remains a new observation.
                self.assertNotEqual(a['source']['generated_at'], b['source']['generated_at'])

    def test_checker_rejects_scoring_slot_and_contribution_corruption(self):
        original = read('new-replays', 'candidate')['cases'][0]
        for mutation in ('scoring', 'slot', 'points', 'subtotal'):
            row = deepcopy(original)
            if mutation == 'scoring':
                row['league']['scoring_settings']['rec'] = 99
            elif mutation == 'slot':
                row['league']['roster_positions'][0] = 'SUPER_FLEX'
            elif mutation == 'points':
                row['phases'][0]['entries'][0]['projected_points'] += 1
            else:
                row['phases'][0]['known_subtotal'] += 1
            with self.subTest(mutation=mutation), self.assertRaises(AssertionError):
                validate(row)


if __name__ == '__main__':
    unittest.main()
