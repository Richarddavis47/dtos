"""Audit these frozen fixtures; this is not another lineup optimizer."""
from collections import Counter
import hashlib
import json
import math


def validate(record):
    league, source = record['league'], record['source']
    scoring = league['scoring_settings']
    digest = hashlib.sha256(json.dumps(scoring, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    assert source['scoring_profile_id'] == digest, 'scoring_profile_mismatch'
    assert source['scoring_settings'] == scoring, 'scoring_metadata_mismatch'
    assert str(source['league_id']) == str(league['league_id']), 'league_identity_mismatch'
    assert int(source['season']) == int(league['season']), 'season_mismatch'
    required = Counter(s for s in league['roster_positions'] if s != 'BN')
    for phase in record['phases']:
        entries = phase['entries']
        assert Counter(e['slot'] for e in entries) + Counter(phase['unsupported_slots']) == required, 'league_slots_mismatch'
        assert len({e['asset_id'] for e in entries}) == len(entries), 'duplicate_starter'
        for entry in entries:
            assert entry['projected_points'] == source['players'][entry['asset_id']]['canonical_projection'], 'source_contribution_mismatch'
        subtotal = sum(e['projected_points'] for e in entries)
        assert math.isclose(subtotal, phase['known_subtotal'], abs_tol=1e-8), 'subtotal_mismatch'
        if phase['available']:
            assert not phase['unsupported_slots']
            assert math.isclose(subtotal, phase['total'], abs_tol=1e-8), 'total_mismatch'
        else:
            assert phase['total'] is None, 'missing_is_not_zero'
    return True
