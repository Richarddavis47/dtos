"""Prepare a decoder sentinel before application observation; no provider facts."""
import hashlib
import json
from pathlib import Path

root = Path('/evidence')
base = (root / 'source-cache-reference.json').read_bytes().rstrip()
assert base.endswith(b'}')
target = root / 'source-cache-dense-boundary.json'
with target.open('wb') as handle:
    handle.write(base[:-1])
    handle.write(b',"fixture_only_decoder_objects":[')
    for _ in range(300):
        handle.write(b'{"x":0},' * 10000)
    handle.seek(-1, 1)
    handle.write(b']}')
print(json.dumps({'scope': 'Fixture preparation before application observation; not provider evidence.',
                  'bytes': target.stat().st_size, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
