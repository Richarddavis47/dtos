"""Unmodified build 2225 admission under measured, enforced disposable pressure."""
import asyncio
import gc
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
from unittest.mock import patch

sys.path.insert(0,str(Path.cwd()))
scratch=tempfile.TemporaryDirectory()
for key,name in {'CACHE':'cache.json','PROJECTION_DB':'projection.sqlite3','METADATA_DB':'metadata.sqlite3',
                 'INTELLIGENCE_CHECKPOINT':'intelligence.sqlite3','FOIS_DB':'fois.sqlite3',
                 'HISTORY_DB':'history.sqlite3','ACCOUNT_DB':'accounts.sqlite3'}.items():
    os.environ['DTOS_'+key+'_FILE']=str(Path(scratch.name)/name)
os.environ.update(DTOS_DURABLE_HISTORY_REQUIRED='0',SLEEPER_BASE_URL='http://127.0.0.1:9/v1',
                  DTOS_SLEEPER_SEASON_CACHE_ROOT=str(Path(scratch.name)/'seasons'),
                  DTOS_HISTORY_STORAGE_ROOT=scratch.name)
import dtos_app
from fastapi.testclient import TestClient
from services import league_preparation as p
from src.core.league_runtime import LeagueRuntime
from src.platform.lifecycle import HeavyWorkDeferred,lifecycle_coordinator,memory_snapshot
from src.platform.memory_reclamation import release_unused_allocator_pages

source=Path('/evidence/source-cache-reference.json')
original_sha=hashlib.sha256(source.read_bytes()).hexdigest()
client=TestClient(dtos_app.app)
limit=2*1024**3
assert memory_snapshot()['cgroup_limit_bytes']==limit
assert Path('/sys/fs/cgroup/memory.swap.max').read_text().strip()=='0'
assert not lifecycle_coordinator.fois_generation_active()
samples=[];stop=threading.Event()
def sample():
    r=memory_snapshot()
    stat=dict(line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())
    return dict(time=time.monotonic(),**r,**{k:int(stat[k]) for k in ('anon','file','kernel')})
def watch():
    while not stop.wait(.01):samples.append(sample())
watcher=threading.Thread(target=watch);watcher.start()
report=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
            tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),
            enforced_limit=limit,cache_bytes=source.stat().st_size,cache_sha256=original_sha,
            working=max(p.CACHE_MINIMUM_WORKING,source.stat().st_size*p.CACHE_EXPANSION_FACTOR),
            safety=p.CACHE_SAFETY,factor=p.CACHE_EXPANSION_FACTOR,phases=[],
            scope='Frozen 17 MiB source-shaped fixture, NOT the uninspected production Granite file. '
                  'Anonymous harness padding is separate and is not production headroom.')
padding=None
def relief():
    global padding
    padding=None;gc.collect();release_unused_allocator_pages()
def pressure(target):
    global padding
    relief();before=memory_snapshot()['cgroup_current_bytes']
    padding=bytearray(max(0,target-before))
    for i in range(0,len(padding),4096):padding[i]=1
    return len(padding)
def publish(runtime):
    projection=dtos_app.ProjectionService(league_id=runtime.league_id,scoring_profile_id=runtime.scoring_profile)
    projection.restore_into(runtime.state['data'])
    dtos_app._publish_runtime_context(runtime,projection)
def run(label,expected):
    r=LeagueRuntime('league-1');observations=[]
    def observed():
        s=memory_snapshot();observations.append(s);return s
    start=len(samples);before=sample();started=time.monotonic()
    with patch.object(p,'league_cache_file',return_value=source),patch.object(p,'memory_snapshot',side_effect=observed),patch.object(p.json,'load',wraps=p.json.load) as decoder:
        try:
            restored=p.restore_cached_runtime(r,publish,expected_season=2026)
            outcome='restored' if restored else 'incompatible'
        except HeavyWorkDeferred:
            outcome='deferred'
        assert outcome==expected,(label,outcome)
        decoded=decoder.call_count
    assert len(observations)==1
    admission=observations[0];required=report['working']+report['safety']
    assert not lifecycle_coordinator.fois_generation_active()
    assert (min(limit,admission['cgroup_limit_bytes'])-admission['cgroup_current_bytes']>=required)==(expected=='restored')
    assert decoded==(1 if expected=='restored' else 0)
    data=r.state.get('data') or {}
    source_ids=dict(r.source_generations)
    if expected=='restored':
        assert data['league']['league_id']=='league-1'
        assert r.lifecycle['preparation_state']=='last_valid'
        assert r.canonical_context is not None
    duration=time.monotonic()-started
    response=client.get('/health/live');assert response.status_code==200
    peak=max([before['cgroup_current_bytes'],memory_snapshot()['cgroup_current_bytes'],
              *[s['cgroup_current_bytes'] for s in samples[start:]]])
    asyncio.run(r.close());del data,r;gc.collect();release_unused_allocator_pages()
    after=sample()
    report['phases'].append(dict(label=label,outcome=outcome,seconds=duration,decode_calls=decoded,
        harness_padding_bytes=len(padding) if padding is not None else 0,before=before,
        exact_admission_sample=admission,required_bytes=required,fois_active=False,
        raw_headroom_bytes=limit-admission['cgroup_current_bytes'],peak_current_bytes=peak,
        observed_increment_bytes=peak-before['cgroup_current_bytes'],after_close=after,
        source_generation_count=len(source_ids),liveness_status=response.status_code,
        lifecycle_phase_after=lifecycle_coordinator.snapshot()['phase']))
try:
    run('healthy_low_pressure','restored')
    pressure(1677201408)
    run('reported_raw_usage_shaped_pressure_no_fois','restored')
    pressure(limit-200*1024**2)
    run('insufficient_headroom_no_competitor','deferred')
    relief()
    run('explicit_retry_after_pressure_relief','restored')
    report['source_unchanged']=hashlib.sha256(source.read_bytes()).hexdigest()==original_sha
    assert report['source_unchanged']
    assert not memory_snapshot()['cgroup_memory_events']['oom_kill']
    report.update(passed=True,complete=True,kernel_peak=int(Path('/sys/fs/cgroup/memory.peak').read_text()),
                  final=sample(),scratch_resources='temporary configured fixture stores removed after inspection')
finally:
    relief();stop.set();watcher.join();client.close();scratch.cleanup()
report['scratch_exists_after']=Path(scratch.name).exists();assert not report['scratch_exists_after']
Path('/evidence/cache-restoration-measurement.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ('phases','final')},indent=2))
