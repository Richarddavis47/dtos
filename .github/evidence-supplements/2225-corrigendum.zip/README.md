# Build 2225 metadata corrigendum and bounded cache-admission diagnosis

This supplement does not change DTOS production code, memory reservations, Trade mathematics or user data. Production remains v1.22.10/build 2225 at `150339f3d02e40ef161a8eb5d870e9b7c38f5874`, tree `e4669e8a4517e29f1d45a332580a52af439adab1`. No build 2226 application release is claimed.

## Correction of my recorder

The original `harness/record-slot-coverage.py` appended mutable references to the fixture league and projection snapshot. Its final Superflex step changed the earlier records' roster/scoring metadata before JSON serialization. This was a recording error. It was not evidence of a production lineup or scoring defect.

Two files in the immutable release's `Trade-lineup-evidence.zip` are affected: `task-records/slot-coverage-baseline.json` and `task-records/slot-coverage-candidate.json`. The archive's SHA-256 is `d92f0503f48bb1a68095e40f3949ad646553fe8180ebc261132db809479e6c1e`. It and its original members are unchanged.

The original files contain eight cases in total. The first three cases in each file (six cases) have incorrect `league.roster_positions`, `league.scoring_settings` and `source.scoring_settings`. Their recorded scoring identifiers and canonical phase records still identify the one-QB calculations. Checksums establish byte integrity, not semantic correctness; the original two files should not be used as self-consistent league-metadata proof without this correction.

`original-records` preserves the exact immutable member bytes. `corrected-original-records` contains separately identified metadata-only copies: the eighteen approved metadata paths are repaired using pinned fixture definitions, recorded scoring hashes and independently reproduced phase records. Every other field, including original timestamps, numerical entries, totals, verdicts and generation identities, is preserved. `CORRECTIONS.json` lists the exact before/after paths and file hashes.

`new-replays` contains newly generated observations using the corrected recorder on the exact original source heads: baseline `11eec0d4fa958c8e68e4e3187dff48d43e067809` and candidate `6fc4d49bec335dc0cc4e2e24ceaf2dedeb2c39aa`. They ran in enforced 2 GiB/two-CPU/no-network containers using Python 3.14.3. Their new generation timestamps are intentionally different from the historical observations. They reproduce the original canonical phase records, numerical values, verdicts and publication identifiers; they are not re-creations of the private live Granite search.

The recorder now deep-copies the complete observation at capture time. Four regression tests reproduce the original six bad metadata records, verify the corrected copies' strictly limited changes, check the pinned replays and reject corrupted scoring, slots, contributions and subtotals. Complete one-QB and Superflex cases remain 40/40 displayed starting assignments; missing DEF remains 38/40, and explicit zero remains supported. These counts describe disposable two-franchise/four-phase fixtures, not live Granite coverage.

## What the November 3 trace establishes

At 17:01:05 UTC, GET `/trades/recommended` returned 503/LeagueRuntimeDeferred. Runtime hydration acquired `cache_persistence`, then failed within about 5 ms. This excludes a conflict acquiring that phase. The deployed restoration function checks memory before decoding and raises the deferred exception from that gate. Source refresh and recommendation search did not run.

The nearby asynchronous memory sample was 1,677,201,408 / 2,147,483,648 bytes: 470,282,240 bytes (448.5 MiB) of raw headroom. No OOM was recorded. This was captured after the decision, not by the admission function itself. No other active diagnostic activity was observed. That does not independently prove that the FOIS reservation boolean was false.

The cache passed its physical reuse precheck (existing eligible regular file within size/age policy); its actual byte size and decoded league/season/scoring compatibility were not recorded in this trace. The requested runtime had no published source generations. A different warm league cannot safely supply Granite's roster/scoring/ownership context. Persisted projection records alone cannot establish a usable roster publication.

The deployed rule is unchanged: working = max(128 MiB, 16 × opened file bytes). Without FOIS it adds a separate 128 MiB safety margin. With an outstanding FOIS reservation it preserves the FOIS 640 MiB work allowance and the larger applicable safety margin. No file-cache subtraction is made.

At the nearby sampled usage, a known-telemetry/no-FOIS decision can admit a file of at most 21,004,032 bytes (about 20.03 MiB). If FOIS is reserved, even the minimum combined requirement is 896 MiB, exceeding the sampled headroom. These are conditional calculations, not measured Granite file size or proof of the unlogged admission inputs. The exact per-file size, exact decision-time memory sample, FOIS flag and detailed rejection code remain unresolved.

Existing Render logs are readable. The configured operations credential returned HTTP 401 for both identity and retention. The available Render connector has no file-stat/SSH operation; no Render CLI/API-key binding is configured in this execution environment. No credentials were exposed, created, repaired or bypassed. A request for a repaired existing inspection binding or a sanitized operator file-stat/admission report remains unanswered at publication. Even the existing retention endpoint exposes aggregate cache bytes rather than an individual Granite file.

## Enforced-container findings

The unmodified production guard was measured with real cgroup telemetry; only the fixture path and observation wrappers were supplied. Telemetry was not fabricated. Harness pressure was allocated and touched, separately recorded, and never subtracted to claim production headroom.

The 17,776,613-byte reference cache is synthetic: it contains 12,229 disposable player identities, including repeated fixture metadata fields. Its structure follows the cache schema; its size, identity distribution and allocation profile are not measurements of Granite or an actual Sleeper publication. It required 284,425,808 working bytes plus 134,217,728 safety bytes. It restored near the reported raw usage (actual admission 1,680,478,208 bytes), reached 1,763,692,544 bytes and completed. With about 206 MB raw headroom, the same unmodified guard deferred before decoding, with no FOIS or heavyweight competitor. Releasing pressure permitted a real subsequent restore. Measured reference-fixture incremental demand was about 77–83 MB, which alone does not justify a smaller universal multiplier.

A separate 41,776,646-byte accepted-format decoder boundary fixture used three million explicitly fixture-only JSON objects outside canonical league data. It is not a real Sleeper population, private Granite data or fabricated history. Actual incremental restoration demand was about 655 MB. An illustrative 8×-plus-safety allowance would be only 468 MB and would admit this fixture with about 521 MB headroom—less than its measured demand. The unchanged 16× policy instead required about 803 MB and deferred. No reduced policy or unsafe decode was executed. This demonstrates a failure of that illustrative lower bound on a deliberately dense accepted-format input; it does not certify a universal worst-case bound.

Both measurements completed cleanup with zero OOM events, no retained scratch directory and released lifecycle ownership. A separate production-source lifecycle proof exercised a real FOIS child, warm/cold cached entry, outstanding FOIS commitment, safe deferral, recovery, child reaping and a real one-QB/FLEX/K/DEF pre/post evaluation. All 74 focused controls passed under 2 GiB, including cancellation ownership, unknown-memory rejection, cooldown, supported navigation and retained-assessment behavior. Full canonical validation was not rerun: no production application source changed, and no application deployment is proposed. Earlier build 2225 passing validation remains historical baseline evidence.

## Original assessment and next safe action

`/trades/recommended` is a page entry, not an assessment-ID lookup. Full generated results live in the original page's `lastOffers` memory; the server does not persist a generated batch for this URL. A selected/previewed/adopted assessment can have bounded, scoped `sessionStorage` evidence marked NOT REVALIDATED. That is conditional on the original browser session and user actions. The new full slot-detail context and rendered HTML are deliberately not persisted. This pass did not inspect the owner's original tab, so it cannot say the assessment is lost or retrievable.

Scout should preserve the original tab before reloading or deliberately entering a fresh Trade session. Check whether the original DOM or a scoped retained assessment actually exists. Do not generate a new search as a substitute. The next operator diagnostic needs the actual Granite cache-file size/mtime and decision-time used/limit/FOIS reservation/reason through an authorized route. Reconcile the existing inspection binding without sending a token or private cache contents. Once safe capacity is established, attempt one normal Granite entry after the existing cooldown; confirm correct league/week/scoring and freshness, with no recommendation search.

No memory policy was lowered, no current Trade or FOIS threshold changed, and no production source, settings or user records were mutated. The production observability gap and the specific unlogged decision inputs remain open; this supplement does not claim a deployed fix for them.
